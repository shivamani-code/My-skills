# Skill: AI Problem-Solving Orchestrator

## Goal
Combine the entire skill system into one repeatable process.

## Trigger

Use this for important problems where originality, reliability, or real-world impact matters.

## Phase 1 — Frame

Use:

`01-problem-decomposition`

Output:

```text
Problem definition
Sub-problems
Constraints
Unknowns
Success definition
```

## Phase 2 — Investigate

Use:

`02-unique-data-acquisition`
`09-evidence-and-source-validation`

Output:

```text
Evidence set
Data gaps
Source map
Confidence levels
```

## Phase 3 — Understand

Use:

`03-first-principles-reasoning`
`06-root-cause-analysis`

Output:

```text
Causal model
Mechanisms
Root causes
Assumptions
```

## Phase 4 — Generate hypotheses

Use:

`04-hypothesis-and-experiment`

Output:

```text
2–5 falsifiable hypotheses
Experiments
Metrics
Baselines
```

## Phase 5 — Attack

Use:

`05-adversarial-ai-critique`
`08-multi-perspective-reasoning`

Output:

```text
Failure modes
Blind spots
Conflicting perspectives
Critical uncertainties
```

## Phase 6 — Engineer

Use:

`07-context-engineering`

Give the AI the complete investigation context.

Ask it to generate implementation options.

Do not ask for "the best solution" without defining the criteria.

## Phase 7 — Test

Build the smallest useful prototype.

Measure:

```text
accuracy
latency
cost
reliability
user outcome
failure rate
```

## Phase 8 — Evaluate

Use:

`10-solution-evaluation`

Compare against the baseline.

## Phase 9 — Learn

Use:

`11-personal-knowledge-system`

Record:

```text
What worked?
What failed?
Why?
What assumption changed?
What should be reused?
What should never be repeated?
```

## Master prompt

```text
I am solving a real problem.

PROBLEM
[problem]

CONTEXT
[context]

EVIDENCE
[evidence]

CONSTRAINTS
[constraints]

PREVIOUS ATTEMPTS
[attempts]

FAILURES
[failures]

CURRENT HYPOTHESES
[hypotheses]

EXPERIMENT RESULTS
[results]

Your role is not to give me a generic answer.

First:
1. Identify what is known.
2. Identify what is uncertain.
3. Challenge my assumptions.
4. Identify missing evidence.
5. Explain the underlying mechanisms.
6. Generate alternative hypotheses.
7. Suggest the smallest experiments that reduce the highest-risk uncertainty.
8. Only then propose implementation options.
9. State trade-offs and failure modes.
10. Clearly distinguish facts, inference, hypotheses, and recommendations.

Never invent evidence or citations.
```

## Final rule

The objective is not:

> "Get a smarter answer from AI."

The objective is:

> "Build a better reasoning process in which AI makes my investigation faster, broader, more critical, and more measurable."

That is the difference between using AI as an answer machine and using AI as a problem-solving system.
