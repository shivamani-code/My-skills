# Skill: Hypothesis & Experiment Design

## Goal
Turn ideas into falsifiable tests.

## Hypothesis format

```text
If [intervention/condition],
then [measurable outcome],
because [mechanism].
```

## Good hypothesis

It can be proven wrong.

Bad:

> AI will improve civic management.

Better:

> A video classifier can detect overflowing public bins with at least X precision under defined lighting conditions.

## Experiment structure

```text
Hypothesis
↓
Variables
↓
Dataset/sample
↓
Baseline
↓
Intervention
↓
Metric
↓
Test
↓
Result
↓
Decision
```

## Always establish a baseline

Compare against:

- current process,
- simple heuristic,
- human judgment,
- existing model,
- previous version.

## AI prompt

```text
Convert my proposed idea into testable hypotheses.

Idea:
[IDEA]

For each hypothesis:
- State it in falsifiable form.
- Identify independent/dependent variables.
- Define a baseline.
- Define measurable success criteria.
- Suggest the smallest experiment that can produce useful evidence.
- Identify confounding factors.
- Tell me what result would falsify it.

Do not assume the hypothesis is true.
```

## Quality check

Never claim an idea works because a prototype runs.

A prototype demonstrates implementation.
An experiment demonstrates evidence.
