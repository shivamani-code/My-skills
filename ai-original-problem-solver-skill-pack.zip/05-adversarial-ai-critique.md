# Skill: Adversarial AI Critique

## Goal
Prevent AI from simply agreeing with your idea.

## Principle

Do not ask:

> "Is this a good idea?"

Ask:

> "What would make this idea fail?"

## Attack modes

### Assumption attack
Find unsupported assumptions.

### Edge-case attack
Find unusual conditions where the solution breaks.

### Cost attack
Find hidden costs.

### Data attack
Find dataset limitations and bias.

### Security attack
Find abuse and adversarial behavior.

### Deployment attack
Find problems that appear outside the prototype.

### Human-factor attack
Find reasons users/operators will not behave as expected.

## AI prompt

```text
Act as an adversarial reviewer.

My proposed solution:
[SOLUTION]

Your job is not to improve it initially.

Try to break it.

Find:
1. Hidden assumptions.
2. Technical failure modes.
3. Data problems.
4. Edge cases.
5. User adoption problems.
6. Security/privacy risks.
7. Scaling problems.
8. Situations where a simpler solution is better.
9. Claims that require evidence.

Rank issues by potential impact, but do not invent evidence.

After the attack, propose experiments that can validate the most dangerous uncertainties.
```

## Rule

Run critique before polishing the solution.

A beautiful solution with untested assumptions is still fragile.
