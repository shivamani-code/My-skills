# Skill: Evidence & Source Validation

## Goal
Prevent plausible-sounding AI output from becoming unsupported claims.

## Claim classification

Every important statement should be classified as:

```text
Verified fact
Source-supported interpretation
Reasonable inference
Hypothesis
Speculation
Unknown
```

## Source hierarchy

Prefer, where applicable:

1. Primary/government sources
2. Official technical documentation
3. Original research papers
4. Standards/specifications
5. High-quality institutional reports
6. Reputable secondary analysis
7. Community discussions
8. Unverified posts

## Verification workflow

```text
Claim
→ source
→ source quality
→ date
→ population/context
→ exact support
→ limitation
```

## AI prompt

```text
Audit these claims:

[CLAIMS]

For each claim:
- Is it directly supported?
- What source would be authoritative?
- Is the source current enough?
- Does the source actually support the exact claim?
- Is this fact, inference, or speculation?
- What uncertainty remains?

Do not fabricate citations.
```

## Quality check

A citation is not evidence merely because it exists.
The source must actually support the claim.
