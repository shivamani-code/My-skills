# Skill: Context Engineering

## Goal
Give AI the exact information and constraints required for high-quality reasoning.

## Why this matters

Generic prompts produce generic outputs because the model has insufficient problem-specific context.

## Context stack

Provide:

```text
1. Objective
2. Problem definition
3. User/context
4. Constraints
5. Available data
6. Existing attempts
7. Failures
8. Success metrics
9. Known uncertainties
10. Required output format
```

## Use structured context

```text
<problem>
...
</problem>

<evidence>
...
</evidence>

<constraints>
...
</constraints>

<attempts>
...
</attempts>

<unknowns>
...
</unknowns>

<task>
...
</task>
```

## AI prompt

```text
You are assisting with a real investigation.

Problem:
[PROBLEM]

Evidence:
[EVIDENCE]

Constraints:
[CONSTRAINTS]

Previous attempts:
[ATTEMPTS]

Known failures:
[FAILURES]

Unknowns:
[UNKNOWNS]

Task:
[TASK]

Rules:
- Do not invent missing facts.
- Distinguish facts from inference.
- State uncertainty.
- Challenge assumptions.
- Prefer evidence-backed reasoning.
- Ask for missing information only when it materially affects the result.
```

## Advanced technique

Feed AI your failures.

A failed attempt tells the model what not to repeat and narrows the search space.

## Quality check

If another user receives essentially the same answer after providing no equivalent context, your context engineering is probably too weak.
