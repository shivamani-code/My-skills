# Skill: Unique Data Acquisition

## Goal
Create an information advantage that generic LLM users do not automatically have.

## Core principle

Your strongest source of originality is often not a better prompt.

It is better evidence.

## Types of useful unique data

- Direct observations
- User interviews
- Local measurements
- Images and videos
- Sensor data
- Logs
- Transaction records
- Operational data
- Before/after measurements
- Failure cases
- Time-series data
- Domain-specific documents
- Your own experiments

## Workflow

### 1. List what the internet/LLM already knows
Do not waste experiments reproducing established knowledge.

### 2. Find the information gap

Ask:

```text
What information would materially change the solution?
Who has that information?
Can I collect it?
Can I measure it?
Can I generate it through an experiment?
```

### 3. Build a dataset

Record metadata wherever possible:

```text
timestamp
location/general context
source
conditions
measurement
confidence
label
notes
```

### 4. Preserve negative evidence

Store:

- failures,
- false positives,
- false negatives,
- unexpected behavior,
- edge cases.

Negative evidence is often more valuable than polished examples.

## AI prompt

```text
Here is the problem:

[PROBLEM]

Here is what is already known:

[KNOWN INFORMATION]

Identify the information that is still missing and could create a meaningful advantage.

For each missing information item:
- Why does it matter?
- How could it be collected?
- What is the cheapest reliable method?
- What decision would it change?
- What bias could the collection method introduce?

Do not invent data.
```

## Quality check

Your dataset should contain information that cannot simply be copied from a generic ChatGPT answer.
