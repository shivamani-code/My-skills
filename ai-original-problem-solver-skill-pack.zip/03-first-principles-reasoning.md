# Skill: First-Principles Reasoning

## Goal
Understand a problem from underlying mechanisms rather than copying existing solutions.

## Method

Start with:

```text
What must be true?
What cannot be avoided?
What is merely a convention?
What physical/technical/social mechanism produces the outcome?
```

## Strip assumptions

For each important statement classify it:

```text
FACT
ASSUMPTION
CONSTRAINT
DESIGN CHOICE
UNKNOWN
```

## Build a causal chain

```text
Input → Mechanism → Intermediate state → Outcome
```

Example:

```text
Heavy traffic
→ reduced vehicle speed
→ longer queue duration
→ increased congestion
→ delayed emergency response
```

Then ask whether the proposed intervention actually changes the mechanism.

## AI prompt

```text
Analyze this problem from first principles:

[PROBLEM]

Do not start with existing products or popular solutions.

1. Identify the fundamental variables.
2. Explain the mechanism causing the outcome.
3. Separate hard constraints from conventions.
4. Identify assumptions that may be false.
5. Derive possible solution directions from the mechanism.
6. Explain where each derivation could fail.

Prefer causal reasoning over brainstorming.
```

## Quality check

You should be able to explain why the solution works without mentioning a competitor, framework, or existing product.
