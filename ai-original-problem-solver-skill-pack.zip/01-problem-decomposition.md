# Skill: Problem Decomposition

## Goal
Convert a vague problem into a precise problem model that can be investigated and tested.

## When to use
Use this before asking AI for solutions to any non-trivial problem.

## Workflow

### 1. Define the problem
Write:

- What is happening?
- Who is affected?
- Where?
- When?
- How frequently?
- What is the measurable impact?
- What would "solved" mean?

### 2. Separate symptom from problem

Do not assume the first complaint is the root problem.

Format:

```text
Observed symptom:
Actual user pain:
Underlying process:
Possible causes:
Constraints:
Desired outcome:
```

### 3. Decompose

Break the problem into independent or semi-independent questions:

```text
Problem
├── Detection
├── Cause
├── User behavior
├── Technical constraints
├── Economic constraints
├── Operational constraints
├── Existing alternatives
└── Measurement
```

### 4. Identify unknowns

Create:

```text
Known facts:
Unknown facts:
Assumptions:
Questions requiring evidence:
```

## AI prompt

```text
I am investigating this problem:

[PROBLEM]

Do not propose a final solution yet.

1. Decompose the problem into the smallest useful sub-problems.
2. Separate symptoms from underlying problems.
3. Identify assumptions I may be making.
4. Identify unknowns that require evidence.
5. Identify dependencies between sub-problems.
6. Tell me which unknowns could invalidate the entire approach.

Do not optimize for creativity. Optimize for accurate problem structure.
```

## Output
A problem map, assumptions list, unknowns list, and measurable definition of success.

## Quality check

You should be able to answer:

- What exactly are we solving?
- What are we not solving?
- What evidence is missing?
- What observation would prove our problem definition wrong?
