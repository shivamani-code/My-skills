# Skill: Multi-Perspective Reasoning

## Goal
Use AI to examine a problem from multiple legitimate perspectives without treating any one perspective as truth.

## Perspectives

Depending on the problem, use:

- End user
- Domain expert
- Engineer
- Researcher
- Security reviewer
- Operations person
- Business analyst
- Skeptic
- Regulator/compliance reviewer
- Accessibility reviewer

## Workflow

Run perspectives independently first.

Then synthesize.

```text
Problem
├── Technical analysis
├── User analysis
├── Operational analysis
├── Security analysis
├── Economic analysis
└── Evidence analysis
        ↓
Conflict map
        ↓
Experiments / decisions
```

## AI prompt

```text
Analyze this problem independently from these perspectives:

[LIST PERSPECTIVES]

Problem:
[PROBLEM]

For each perspective:
- Key concern
- Important assumption
- Proposed approach
- Failure mode
- Evidence required

Do not merge the answers until all perspectives are complete.

Then identify:
- agreements,
- disagreements,
- unresolved questions,
- questions that can be tested.
```

## Rule

Multiple AI personas do not magically create truth.
They are useful for exposing blind spots.
