# Skill: Personal Knowledge System

## Goal
Turn your accumulated work into an advantage that compounds over time.

## Store five things

### 1. Observations
What you actually saw.

### 2. Evidence
What supports a conclusion.

### 3. Experiments
What you tested and how.

### 4. Failures
What did not work and why.

### 5. Insights
Reusable principles derived from evidence.

## Recommended structure

```text
knowledge/
├── problems/
├── datasets/
├── experiments/
├── failures/
├── research/
├── architectures/
├── patterns/
└── decisions/
```

## Experiment record

```text
# Experiment

Problem:
Hypothesis:
Date:
Dataset:
Method:
Baseline:
Result:
Unexpected result:
Failure modes:
Conclusion:
Next experiment:
```

## Decision record

```text
Decision:
Context:
Options:
Evidence:
Assumptions:
Chosen approach:
Why:
Trade-offs:
Revisit condition:
```

## AI usage

Give AI access to your accumulated project context when appropriate.

Ask:

```text
Based only on my previous experiments and evidence,
what patterns are emerging?

Which assumptions keep failing?

Which approaches repeatedly work?

What unexplored connection exists between these observations?
```

## Core principle

Your knowledge base becomes a personalized reasoning substrate.

The longer you investigate real problems, the harder it becomes for a generic one-shot AI interaction to reproduce your exact reasoning path.
