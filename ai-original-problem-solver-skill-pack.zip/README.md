# AI Original Problem Solver — Skill Pack

## Purpose
This skill pack is designed for solving problems with AI without falling into generic, one-shot LLM answers.

Core principle:

> Do not use AI to replace your reasoning. Use AI to amplify investigation, challenge assumptions, analyze evidence, run experiments, and accelerate implementation.

## Core loop

PROBLEM → DECOMPOSE → COLLECT UNIQUE EVIDENCE → FORM HYPOTHESES → CHALLENGE → EXPERIMENT → ANALYZE → BUILD → MEASURE → ITERATE

## Skills

1. `01-problem-decomposition.md` — turn vague problems into precise sub-problems.
2. `02-unique-data-acquisition.md` — create an evidence advantage using original/grounded data.
3. `03-first-principles-reasoning.md` — reason from mechanisms instead of copied patterns.
4. `04-hypothesis-and-experiment.md` — convert ideas into testable hypotheses.
5. `05-adversarial-ai-critique.md` — force AI to attack your solution rather than flatter it.
6. `06-root-cause-analysis.md` — separate symptoms, causes, constraints, and feedback loops.
7. `07-context-engineering.md` — give AI the right context, constraints, evidence, and task structure.
8. `08-multi-perspective-reasoning.md` — use different analytical roles without blindly trusting any one output.
9. `09-evidence-and-source-validation.md` — verify claims and distinguish fact, inference, and speculation.
10. `10-solution-evaluation.md` — measure solutions against explicit criteria and real-world tests.
11. `11-personal-knowledge-system.md` — turn your projects, failures, experiments, and datasets into reusable intelligence.
12. `12-ai-problem-solving-orchestrator.md` — combine all skills into one end-to-end workflow.

## Recommended usage

For a new problem:

1. Run Problem Decomposition.
2. Identify what unique evidence you can collect.
3. Build a first-principles model.
4. Write 2–5 hypotheses.
5. Ask AI to attack them.
6. Design the cheapest useful experiment.
7. Collect results.
8. Update your model.
9. Engineer the solution.
10. Evaluate it against reality.
11. Record what you learned.

## Anti-generic rule

Never accept an AI answer merely because it sounds sophisticated.

Require at least one of:

- evidence,
- a test,
- a calculation,
- a concrete mechanism,
- a source,
- an observed pattern,
- a measurable result,
- or a clearly stated uncertainty.
