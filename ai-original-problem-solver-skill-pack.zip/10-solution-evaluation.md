# Skill: Solution Evaluation

## Goal
Evaluate a solution using measurable criteria rather than intuition or AI enthusiasm.

## Define criteria

Typical dimensions:

```text
Effectiveness
Accuracy
Reliability
Latency
Cost
Scalability
Maintainability
Security
Privacy
Accessibility
User adoption
Operational complexity
Environmental impact
```

Only use dimensions relevant to the problem.

## Compare against a baseline

```text
Current approach
vs.
Proposed approach
```

Use actual measurements where possible.

## Evaluation table

```text
Metric | Baseline | Proposed | Target | Evidence
```

## AI prompt

```text
Evaluate this solution:

[SOLUTION]

Context:
[CONTEXT]

Metrics:
[METRICS]

Baseline:
[BASELINE]

Do not declare it successful from design quality alone.

Identify:
- what can be measured,
- how to measure it,
- minimum acceptable threshold,
- likely failure modes,
- missing evidence,
- tests needed before deployment.
```

## Quality check

Do not confuse:

```text
Novel ≠ useful
Working demo ≠ reliable system
High benchmark score ≠ real-world performance
AI-generated explanation ≠ evidence
```
