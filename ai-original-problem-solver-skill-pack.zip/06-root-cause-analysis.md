# Skill: Root Cause Analysis

## Goal
Avoid treating symptoms while the underlying cause remains.

## Core tools

Use whichever fits the problem:

- 5 Whys
- Fishbone/Ishikawa
- Fault tree
- Causal graph
- Process mapping
- Failure Mode and Effects Analysis
- Counterfactual reasoning

## Workflow

```text
Symptom
→ immediate cause
→ contributing cause
→ system cause
→ root constraint
```

Do not assume there is only one root cause.

## Counterfactual test

Ask:

> If this suspected cause disappeared, would the problem disappear?

If not, it is probably not sufficient as the root cause.

## AI prompt

```text
Analyze this problem for root causes:

[PROBLEM]

Build a causal chain.

For each proposed cause:
- What evidence supports it?
- What evidence would contradict it?
- Is it necessary?
- Is it sufficient?
- What alternative causes exist?
- What observation would distinguish the causes?

Do not label a cause as confirmed without evidence.
```

## Quality check

The final intervention should target a causal mechanism, not merely make the symptom look better.
