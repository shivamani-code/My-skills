# VERIFICATION.md

What was actually checked, with the results. Commands are reproducible from the extracted pack:
`verification/verify-against-upstream.sh` and `verification/check-local-references.sh`.

Source: `https://github.com/edenfunf/reelmimic` @ `782a3ba3cfa455663127348dbfcbcfafada05d52` (`main`).

---

## 1. Skill folders discovered — 36

`find .claude/skills -mindepth 1 -maxdepth 1 -type d` → **36 folders**, and `git ls-files .claude/skills`
→ **1077 tracked files**; the working tree held 1077 files too, so nothing in the skills tree was
untracked or missing. All 36 are packaged.

```
anime-cel          faceless-explainer   hyperframes-registry  music-to-video        pixel-art             slideshow
blender-product-   ffmpeg               hyperframes-studio    oversized-cursor      pr-to-video           talking-head-recut
  film             figma                hyperframes           painted-animation     product-launch-video  video-clone
captions-overlay   frontend-design      media-use             paper-cutout          remotion-to-           whiteboard
crayon-storybook   general-video        motion-doctrine                             hyperframes
cut-the-curve      hyperframes-         motion-graphics
embedded-captions    animation
                   hyperframes-audio
                   hyperframes-cli
                   hyperframes-core
                   hyperframes-creative
                   hyperframes-keyframes
```

## 2. `SKILL.md` files — 36 (one per folder)

`find skills -name SKILL.md | wc -l` → **36**. Every one of the 36 folders contains exactly one
`SKILL.md`; no folder lacks one, and no folder has more than one.

```
skills/anime-cel/SKILL.md                     skills/hyperframes-studio/SKILL.md
skills/blender-product-film/SKILL.md          skills/hyperframes/SKILL.md
skills/captions-overlay/SKILL.md              skills/media-use/SKILL.md
skills/crayon-storybook/SKILL.md              skills/motion-doctrine/SKILL.md
skills/cut-the-curve/SKILL.md                 skills/motion-graphics/SKILL.md
skills/embedded-captions/SKILL.md             skills/music-to-video/SKILL.md
skills/faceless-explainer/SKILL.md            skills/oversized-cursor/SKILL.md
skills/ffmpeg/SKILL.md                        skills/painted-animation/SKILL.md
skills/figma/SKILL.md                         skills/paper-cutout/SKILL.md
skills/frontend-design/SKILL.md               skills/pixel-art/SKILL.md
skills/general-video/SKILL.md                 skills/pr-to-video/SKILL.md
skills/hyperframes-animation/SKILL.md         skills/product-launch-video/SKILL.md
skills/hyperframes-audio/SKILL.md             skills/remotion-to-hyperframes/SKILL.md
skills/hyperframes-cli/SKILL.md               skills/seam-craft/SKILL.md
skills/hyperframes-core/SKILL.md              skills/slideshow/SKILL.md
skills/hyperframes-creative/SKILL.md          skills/talking-head-recut/SKILL.md
skills/hyperframes-keyframes/SKILL.md         skills/video-clone/SKILL.md
skills/hyperframes-registry/SKILL.md          skills/whiteboard/SKILL.md
```

## 3. Every discovered folder represented — 36/36

Because the hash check in §5 covers **all 1077 upstream skill paths** and every one of them exists in the
pack with an identical blob hash, the packaged set of files is exactly the upstream set: no folder is
missing, and no file inside any folder is missing either. Per-folder counts
(`verification/skills-inventory.tsv`) sum to 1077.

Files that live outside `.claude/skills/` and are needed for the workflows: 13 packaged, listed in
`SOURCE_MANIFEST.md` §4 with their original paths.

## 4. Referenced scripts, templates and assets

Method: every relative reference (`../…`) written inside the 1077 files was extracted, and each
referenced **filename** was searched for anywhere in the pack
(`bash verification/check-local-references.sh`).

```
distinct relative references scanned: 125
targets not found anywhere in the pack: 11
```

The 11, reviewed by hand — none of them is an unnoticed omission:

| Reference | Verdict |
|---|---|
| `../../../packages/cli/dist/cli.js` | The HyperFrames CLI. Not in the repository at all; install from npm or point `HYPERFRAMES_ROOT` at a built checkout. Documented: `DEPENDENCIES.md` §1/§6. |
| `../../../packages/player/dist/hyperframes-player.global.js`, `.../slideshow/hyperframes-slideshow.global.js` | HyperFrames player bundles for the `slideshow` standalone harness. Same external package, documented in `DEPENDENCIES.md` §6. |
| `../../registry/components/motion-blur/motion-blur.html` | A snippet from the upstream HyperFrames component registry, fetched with `npx hyperframes add`. Documented, `SOURCE_MANIFEST.md` §6. |
| `../capture/assets/fonts/Fraunces-Variable.woff2`, `../capture/assets/fonts/.`, `../capture/assets/lottie/animation-0.json`, `../capture/assets/videos/clip.mp4` | Paths **inside a scaffolded HyperFrames project** (`capture/assets/…` is what `hyperframes capture` writes), not pack paths — see `faceless-explainer/scripts/build-frame.mjs:474` and `captions.mjs:287-302`. Nothing to package. |
| `../../media-use/audio/scripts/audio.mjs.` | Trailing period from prose. The real file `skills/media-use/audio/scripts/audio.mjs` **is** packaged (basename match fails only because of the period). |
| `../..`, `../../..` | Directory expressions in code that locate a HyperFrames checkout (`path.resolve(__dirname, "../../..")`). Not file references; covered by `HYPERFRAMES_ROOT` above. |

Cross-skill references that *do* resolve were validated in place, e.g.
`faceless-explainer/scripts/frame-packets.mjs` → `../hyperframes/references/frame-worker-core.md`,
`media-use/audio/scripts/lib/tts.mjs` → `../../../scripts/lib/media-fetch.mjs`,
`pr-to-video/…` → `../../../faceless-explainer/scripts/lib/tokens.mjs`, and the 9 `music-to-video`
templates → `../../motion-primitives/assets/gsap.min.js` (the `gsap.min.js` copy that ships inside
`music-to-video/references/motion-primitives/assets/`). This is exactly why the 36 folders must stay
siblings.

## 5. Hash comparison — 1090 / 1090 identical

Method: each packaged file is hashed as raw bytes (`git hash-object --no-filters`), and compared with the
blob SHA-1 recorded in the upstream git index (`git ls-files -s`), i.e. the bytes upstream itself stores.
Line-ending conversion therefore cannot mask or fake a match.

| Checkpoint | Checked | Missing | Mismatched |
|---|---:|---:|---:|
| Staging tree (before zipping) — 1077 skills + 13 support files | 1090 | 0 | 0 |
| After ZIP extraction into a fresh directory — same 1090 files | 1090 | 0 | 0 |

Why this mattered: the first extraction attempt used a plain `git archive`, which inherited
`core.autocrlf=true` and silently converted LF→CRLF in 909 of the 1077 files. That was caught by this
check, and the pack was rebuilt from git objects with conversion disabled
(`git -c core.autocrlf=false -c core.eol=lf archive …`). The current pack is the corrected one.

The full expected list of upstream hashes is `verification/upstream-blob-hashes.txt` (1077 lines, original
`.claude/skills/…` paths), so the check can be repeated independently:

```bash
bash verification/verify-against-upstream.sh            # clones the pinned commit itself
bash verification/verify-against-upstream.sh /path/to/reelmimic-clone
```

## 6. ZIP extraction test

```bash
unzip -t reelmimic-original-skills-and-dependencies.zip     # No errors detected
mkdir /tmp/ziptest && cd /tmp/ziptest
unzip -q reelmimic-original-skills-and-dependencies.zip
```

Results on the extracted copy:

| Measurement | Result |
|---|---|
| `ls -1 <root>/skills \| wc -l` | 36 |
| `find <root>/skills -type f \| wc -l` | 1077 |
| `find <root>/skills -name SKILL.md \| wc -l` | 36 |
| `find <root> -type f \| wc -l` | 1101 (1077 skills + 13 support + 11 packaging docs/scripts) |
| `find <root> -type d \| wc -l` | 281 |
| Hidden file preserved | `shared-dependencies/.claude/settings.json` present after extraction |
| Top-level entries | `skills/`, `shared-dependencies/`, `licenses/`, `verification/`, `README.md`, `SOURCE_MANIFEST.md`, `ANYTHINGLLM_SETUP.md`, `DEPENDENCIES.md`, `VERIFICATION.md` |
| Archive size | ~23.9 MB compressed (≈29.5 MB of content; most of the remaining weight is fonts, PNG/JPG sheets and woff2 files that do not compress) |

## 7. Missing dependencies and untested workflows

**Deliberately absent from upstream (documented, not omitted by this pack)** — `SOURCE_MANIFEST.md` §6,
`DEPENDENCIES.md` §6:

1. The HyperFrames CLI/player (`packages/cli`, `packages/player`) — npm package `hyperframes`.
2. The upstream component registry (`registry/components/**`).
3. Pixabay sound effects in `media-use/audio/assets/sfx/*.mp3` (licence forbids redistribution).
4. `u2net_human_seg.onnx` matting weights — downloaded on first `hyperframes remove-background` run.
5. The twelve `remotion-*` skills from `remotion-dev/skills` (no upstream licence). Consequence:
   `video-clone/styles/remotion-react.md` cannot be used from this pack alone.
6. The `app/` web application, including its `npm run doctor` environment checker and its installers.

**Not tested (and therefore not claimed to work):**

- No video was rendered, and no engine was executed. The skill scripts, the HyperFrames CLI, `puppeteer`,
  Chrome, FFmpeg and the Python stack were never run from this pack.
- No dependency was installed (`npm`, `pip`, `bun` were not run for this pack), so the dependency lists in
  `DEPENDENCIES.md` are derived from the skills' own commands/imports/env reads, not from a successful run.
- AnythingLLM itself was not configured: no knowledge upload, no custom agent skill, no MCP server, and no
  AnythingLLM instance was contacted.
- The Python and Node test suites that ship inside several skills
  (e.g. `embedded-captions/scripts/*.test.mjs`, `hyperframes-animation/scripts/*.test.mjs`,
  `media-use/audio/scripts/*.test.mjs`) were not executed.
- `verification/check-local-references.sh` matches referenced basenames anywhere in the pack, which is a
  strong signal for "the file is here" but not proof that a given relative path resolves at runtime; the
  11 exceptions above were reviewed by hand for that reason.

## 8. Confirmation

- **36 of 36** original skill folders are present, each with its `SKILL.md`.
- **1077 of 1077** original skill files are present, all byte-identical to upstream
  (`git hash-object --no-filters` == upstream blob SHA-1).
- **1090 of 1090** upstream-derived files in the pack (skills + the 13 supporting files) verified.
- Nothing under `skills/` was rewritten, summarised, reformatted or regenerated. The pack's own documents
  (`README.md`, `SOURCE_MANIFEST.md`, `ANYTHINGLLM_SETUP.md`, `DEPENDENCIES.md`, `VERIFICATION.md`,
  `licenses/README.md`, `shared-dependencies/README.md`, `verification/*`) are additions, and none of them
  replaces a skill file.
