# DEPENDENCIES.md

Everything the 36 packaged skills need in order to actually run, what is bundled here, what has to be
installed separately, and what could not be verified.

Nothing in this file changes a skill: the skills' own instructions stay exactly as upstream wrote them.
Where a skill's own text already states a requirement, that text is the authority.

---

## 1. Required software

| Requirement | Version | Needed by | Notes / source of the requirement |
|---|---|---|---|
| **Node.js** | **≥ 22.18** | every engine's `render.mjs`, all `.mjs`/`.cjs` helper scripts | Upstream's own `engines` field is `"node": ">=22.18"`; the README states Node 22.18+. |
| **A Chromium-based browser** | current Chrome / Chromium / Edge | every HTML→video render (`puppeteer-core` with no bundled browser) | `template/package.json` in the six engine templates declares only `puppeteer-core@^25.11.0`, which needs an existing browser binary. Set `CHROME_PATH` if it is not auto-detected. |
| **FFmpeg** (and `ffprobe`) | 5.0+ recommended (any recent build) | `embedded-captions` scripts, `video-clone` analysis/assembly, engine renders, `media-use` audio/video work, `ffmpeg` skill | Skills call `ffmpeg` by name; set `FFMPEG_DIR` when it is not on `PATH`. |
| **Python** | **≥ 3.10** | `video-clone` (`analyze.py`, `fetch_assets.py`, `align_lyrics.py`, `compare.py`, `timeline.py`, `clip_strip.py`, `motion_check.py`, `yating_tts.py`, `hf_frames.py`), `blender-product-film` (4 scripts), `painted-animation/scripts/beat_grid.py`, `music-to-video/scripts/analyze-beatgrid.py`, `hyperframes-creative`, `media-use`, `remotion-to-hyperframes/scripts/lint_source.py` | Upstream README states Python 3.10+; the installer picks `python3`, `python` or `py`, so set `PYTHON=<path>` if the wrong one is found. |
| **HyperFrames CLI** | any recent release; upstream's own fixtures were measured against **0.7.71**, and skills invoke `npx hyperframes@latest` | the entire `hyperframes*` family, `embedded-captions`, `faceless-explainer`, `general-video`, `media-use`, `motion-graphics`, `music-to-video`, `pr-to-video`, `product-launch-video`, `slideshow`, `talking-head-recut`, `figma`, `motion-doctrine`, `video-clone` (motion-graphics style) | **Not bundled.** It is the `hyperframes` npm package (`@hyperframes/cli` is the same project); run it as `npx hyperframes …` or `npm i -g hyperframes`. Verified by grepping all 1077 skill files: 30 distinct `npx hyperframes …` subcommands appear. |
| **An AI coding agent** | Claude Code (`npm i -g @anthropic-ai/claude-code`) or Codex CLI (`npm i -g @openai/codex`), logged in | all of them | The skills are instructions for an agent that can run shell commands and read files. Without such an agent (or an equivalent execution tool) nothing here runs — see [ANYTHINGLLM_SETUP.md](ANYTHINGLLM_SETUP.md). |

### HyperFrames checkout vs. npm CLI — the one real trap

Most skills are CLI-driven (`npx hyperframes render …`) and work with just the npm package. But three
scripts resolve a **source checkout** of the HyperFrames monorepo by relative path and fail without one:

- `embedded-captions/scripts/render-and-composite.sh` — needs `<root>/packages/cli/dist/cli.js`; it
  checks, in order: `$2` (repo path argument) → `$HYPERFRAMES_ROOT` → `../../../` from the script →
  `~/Downloads/hyperframes`.
- `embedded-captions/scripts/check-occlusion.cjs` and `check-overflow.cjs` / `measure-layout.cjs` — load
  `sharp` and `puppeteer` out of that checkout's `node_modules`; candidate roots are
  `$HYPERFRAMES_ROOT` → `../../../` → `~/Downloads/hyperframes`.
- `media-use/scripts/resolve.mjs` — tries `<root>/packages/cli/dist/cli.js`, else `bun
  <root>/packages/cli/src/cli.ts`.

Because this pack places skills at `skills/<name>/` (and ReelMimic places them at
`.claude/skills/<name>/`), the `../../../` candidate resolves to the *parent of the skills directory*,
not to a HyperFrames checkout. So for those scripts you must either:

```bash
export HYPERFRAMES_ROOT=/path/to/hyperframes     # a clone built with: bun install && bun run build
# or pass it as the second argument: bash render-and-composite.sh <project> /path/to/hyperframes
```

`bun` is only needed to build a checkout from source; it is not needed to use the npm CLI.

## 2. Bundled with this pack

| Bundled | Where | Role |
|---|---|---|
| 36 skill folders, 1077 files | `skills/` | The skills themselves, including every script, template, reference, font, theme, DNA, blueprint, preset and test fixture they ship |
| Template `package.json` + `package-lock.json` (`anime-cel`, `crayon-storybook`, `painted-animation`, `paper-cutout`, `pixel-art`, `whiteboard`) | inside `skills/<engine>/template/` | `npm ci` inside a scaffolded project reproduces the template dependency tree (`puppeteer-core`, and `p5` + `p5.brush` for the p5-based engines) |
| `requirements.txt` | `shared-dependencies/requirements.txt` | Python package list (see §3) |
| `.claude/settings.json` | `shared-dependencies/.claude/settings.json` | `HYPERFRAMES_NO_TELEMETRY=1`, `DO_NOT_TRACK=1`, `REMOTION_TELEMETRY_DISABLED=1` — copy to `<project>/.claude/settings.json` |
| `skills-lock.json` | `shared-dependencies/skills-lock.json` | Upstream source repo + `computedHash` per skill (34 entries) |
| Fonts, palettes, presets, templates, test corpus docs | inside `skills/` | e.g. `embedded-captions/modes/standard/fonts/files/*.woff2` (44 font files), `hyperframes-creative/frame-presets/**`, `music-to-video/references/{templates,motion-primitives}/**` (83 HTML compositions + 66 PNG masks + GSAP) |

**Not bundled, by design:** `node_modules` anywhere, any rendered output, and the npm/pip packages
themselves. Install them where §1 says.

## 3. Python packages

`shared-dependencies/requirements.txt` (upstream's file, unmodified):

| Package | Kind | Used for |
|---|---|---|
| `numpy`, `opencv-python` | required | frame analysis, shot/colour metrics |
| `scenedetect` | required | shot-boundary detection in reference videos |
| `librosa` | required | BPM / beat-grid / audio feature analysis |
| `Pillow` | required | image work, sheets, contact sheets |
| `yt-dlp` | required | downloading reference videos (invoked as `python -m yt_dlp`) |
| `faster-whisper` | optional | automatic lyrics timing against the user's audio (`video-clone/scripts/align_lyrics.py`) |
| `opencc-python-reimplemented` | optional | Chinese conversion for lyric alignment |

Two further Python paths are documented by the skills themselves rather than in `requirements.txt`:

- `media-use/scripts/transcribe.mjs` looks for **parakeet-mlx** at `$HYPERFRAMES_PARAKEET`, then
  `~/.venvs/parakeet`, then `PATH` (its own suggested install:
  `uv venv ~/.venvs/parakeet && VIRTUAL_ENV=~/.venvs/parakeet uv pip install parakeet-mlx`), and can
  fall back to Whisper with `--engine whisper`.
- `embedded-captions/scripts/transcribe.cjs` uses WhisperX by default (`TRANSCRIBE_ENGINE=whisperx`) or
  Whisper (`TRANSCRIBE_ENGINE=whisper`); `WHISPER_MODEL` / `WHISPER_LANG` select the model/language.

## 4. Models, services and API keys

None of these is required for the pure-Markdown skills; each is limited to the workflows the table names.

| Dependency | Env var / key | Needed by | How it behaves without it |
|---|---|---|---|
| HyperFrames background removal model `u2net_human_seg.onnx` (~168 MB) | — | `embedded-captions/scripts/matte.cjs` (via `hyperframes remove-background`) | Downloaded once to `~/.cache/hyperframes/background-removal/models/` on first use. Model load takes 1–2 min with no output — the script says so explicitly. |
| HeyGen TTS / media API | `HEYGEN_API_KEY`, `HEYGEN_CONFIG_DIR` | `media-use/audio/scripts/lib/heygen.mjs`, `heygen-tts.mjs` | Speech/subtitle work falls back to other engines or fails |
| Google Gemini (TTS + grounding) | `GEMINI_API_KEY` or `GOOGLE_API_KEY` | `media-use/audio/scripts/lib/gemini-auth.mjs`, `gemini-tts.mjs`, `media-use/scripts/lyria-recipe.py`, `motion-graphics/grounding/locate.mjs` | Those narration/grounding paths are unavailable |
| ElevenLabs | `ELEVENLABS_API_KEY` | `product-launch-video/scripts/audio.mjs` (`--provider` / `HF_TTS_PROVIDER`) | Falls back to the provider the CLI picks by default |
| Yating TTS (Taiwanese Mandarin) | `YATING_KEY` | `video-clone/scripts/yating_tts.py`, narration in `video-clone` | Mandarin narration unavailable; write your own VO |
| Pixabay / Freesound / Openverse assets | `PIXABAY_KEY`, `FREESOUND_KEY` | `video-clone/scripts/fetch_assets.py`, `media-use` asset resolution | Openverse needs no key; without the others, fewer licence-safe assets |
| HyperFrames cloud render | `HYPERFRAMES_API_KEY` | `hyperframes-cli/references/cloud.md`, `cloudrun.md` | Local rendering is unaffected |
| Google Cloud (bulk/CI rendering docs) | `GCS_CREDS`, `GOOGLE_APPLICATION_CREDENTIALS`, `GOOGLE_CLOUD_PROJECT` / `GCLOUD_PROJECT_ID` | `hyperframes-cli` cloud references | Local rendering is unaffected |
| Blender | `BLENDER` (or on `PATH`) | `blender-product-film` (Blender 4.2+, GPU with OptiX/CUDA recommended) | That skill cannot run at all; it is 3D and upstream's own rules mark the 3D track paused |
| Real-ESRGAN (`realesrgan-ncnn-vulkan`) | `REALESRGAN` | `blender-product-film` (optional) | Output stays at base resolution |
| Remotion | `@remotion/cli`, `react`, `react-dom`, `remotion` (and `zod` for the data-driven fixture) | `remotion-to-hyperframes/assets/test-corpus/**` only | The skill's conversion guidance still works; its regression corpus cannot be regenerated |
| Remotion skills (12 of them, `remotion-dev/skills`) | — | `video-clone/styles/remotion-react.md` | **Not redistributable** (upstream has no licence file). That one style is unusable from this pack; install those skills yourself if you need it. |

Reference: the full per-path licence/provenance table is `licenses/THIRD_PARTY_NOTICES.md`, which also
lists what upstream deliberately does not bundle.

## 5. Per-skill dependency profile

Generated from the packaged files (`verification/skills-inventory.tsv` has counts and extensions).
"HyperFrames CLI" means the skill's files contain an `npx hyperframes …` command line.

| Skill | Files | JS | Py | SH | HyperFrames CLI | Engine/template deps | Other |
|---|---:|---:|--:|--:|---|---|---|
| `anime-cel` | 24 | yes | — | yes | no | `puppeteer-core` (template lockfile included) | FFmpeg, Chrome |
| `blender-product-film` | 5 | — | yes | — | no | — | Blender 4.2+, FFmpeg, optional Real-ESRGAN |
| `captions-overlay` | 1 | — | — | — | no | — | instructions only |
| `crayon-storybook` | 21 | yes | — | yes | no | `p5`, `p5.brush`, `puppeteer-core` | FFmpeg, Chrome |
| `cut-the-curve` | 2 | — | — | — | no | — | instructions only |
| `embedded-captions` | 141 | yes | yes | yes | yes | `sharp` + `puppeteer` from a HyperFrames checkout | FFmpeg, matting model, WhisperX/Whisper |
| `faceless-explainer` | 27 | yes | — | — | yes | `$HF_MEDIA_ENGINE` (media audio engine from the checkout) | Node ≥ 22.18 |
| `ffmpeg` | 2 | — | — | — | no | — | FFmpeg (it is a reference skill about it) |
| `figma` | 2 | yes | — | — | yes | — | HyperFrames CLI |
| `frontend-design` | 2 | — | — | — | no | — | instructions only |
| `general-video` | 5 | yes | — | — | yes | — | Node ≥ 22.18 |
| `hyperframes-animation` | 122 | yes | — | — | yes | GSAP / anime.js / Lottie / Three.js / TypeGPU / WAAPI, loaded per project by the CLI scaffold | referenced `registry/…` snippet lives upstream (see §6) |
| `hyperframes-audio` | 7 | yes | — | — | yes | — | FFmpeg |
| `hyperframes-cli` | 11 | — | — | — | yes | — | HyperFrames CLI, docs only (no scripts) |
| `hyperframes-core` | 11 | — | — | — | yes | Tailwind v4 browser runtime (pinned `@tailwindcss/browser@4.2.4`) | docs only |
| `hyperframes-creative` | 79 | yes | yes | — | yes | frame presets incl. 6 fonts | FFmpeg |
| `hyperframes-keyframes` | 3 | — | — | — | yes | — | docs only |
| `hyperframes-registry` | 12 | — | — | — | yes | — | needs `npx hyperframes add` / `catalog` |
| `hyperframes-studio` | 1 | — | — | — | no | — | docs only |
| `hyperframes` | 26 | yes | — | — | yes | — | the orchestration skill |
| `media-use` | 80 | yes | yes | — | yes | — | FFmpeg, TTS providers, parakeet/Whisper, `sharp`/`puppeteer` via checkout |
| `motion-doctrine` | 4 | yes | — | — | yes | `puppeteer-core` | `npx hyperframes preview` as the seam gate |
| `motion-graphics` | 23 | yes | — | — | yes | `puppeteer-core` | FFmpeg, optional Gemini for grounding |
| `music-to-video` | 169 | yes | yes | — | yes | 83 HTML templates/motion primitives + 66 PNG masks + bundled GSAP | FFmpeg, Chrome, beat analysis |
| `oversized-cursor` | 1 | — | — | — | no | — | instructions only |
| `painted-animation` | 31 | yes | yes | yes | no | `p5`, `p5.brush`, `puppeteer-core` | FFmpeg, Chrome, Python |
| `paper-cutout` | 17 | yes | — | yes | no | `puppeteer-core` | FFmpeg, Chrome |
| `pixel-art` | 19 | yes | — | yes | no | `puppeteer-core` | FFmpeg, Chrome |
| `pr-to-video` | 33 | yes | — | — | yes | — | GitHub PR data (its own `fetch-pr.mjs`) |
| `product-launch-video` | 34 | yes | — | — | yes | — | optional ElevenLabs TTS |
| `remotion-to-hyperframes` | 77 | — | yes | yes | yes | Remotion 4 / React 18 / zod in the test corpus | HyperFrames checkout (`run.sh` wants `packages/cli/dist/cli.js`) |
| `seam-craft` | 1 | — | — | — | no | — | instructions only |
| `slideshow` | 2 | — | — | — | yes | HyperFrames player bundles (`packages/player/dist/…`, upstream only) | docs only |
| `talking-head-recut` | 28 | yes | — | — | yes | 6 bundled fonts + `gsap.min.js` | FFmpeg |
| `video-clone` | 35 | yes | yes | yes | yes (motion-graphics style) | 14 style files + engine-kit (puppeteer-core) | FFmpeg, Python stack, yt-dlp, optional yating/whisper |
| `whiteboard` | 19 | yes | — | yes | no | `puppeteer-core` | FFmpeg, Chrome |

## 6. Referenced but not shipped anywhere (upstream gaps)

1. **`packages/cli/dist/cli.js`, `packages/cli/src/**`, `packages/player/dist/*.js`** — the HyperFrames
   CLI and player. Install from npm (`hyperframes`), or clone and build HyperFrames and set
   `HYPERFRAMES_ROOT`.
2. **`registry/components/*` and `registry/registry.json`** — the block/component registry described in
   `hyperframes-animation/references/motion-blur.md` and `hyperframes-registry/references/contributing.md`.
   Reached through `npx hyperframes add <block>` / `npx hyperframes catalog`, which pull from upstream.
3. **`media-use/audio/assets/sfx/*.mp3`** — deliberately excluded upstream (Pixabay Content License
   forbids redistributing the files standalone). The folder ships `CREDITS.md` + `manifest.json`; get the
   files from the links in `CREDITS.md`, or let the workflow fetch licence-safe SFX itself.
4. **No `.onnx` matting weights exist in the repository** at this commit, despite the comment in
   `embedded-captions/.gitignore` claiming a PP-MattingV2 file "ships with the skill". Matting goes
   through `hyperframes remove-background`, which downloads §4's model on first run.
5. **Twelve `remotion-*` skills** are pinned in `skills-lock.json` but not distributed (no upstream
   licence). One `video-clone` style expects one of them.
6. **The web app's environment checker** (`app/scripts/doctor.mjs`, `npm run doctor`) is in the excluded
   `app/` folder. Perform the same checks by hand:

```bash
node --version                 # expect v22.18+
python --version               # expect 3.10+ (or: py -3 --version)
python -m pip show numpy opencv-python scenedetect librosa Pillow yt-dlp
ffmpeg -version && ffprobe -version
"$CHROME_PATH" --version 2>/dev/null || google-chrome --version || chromium --version
npx --yes hyperframes doctor    # the CLI's own environment check
claude --version || codex --version
```

## 7. Environment variables

Set only what applies to you; every one is optional if the tool is on `PATH`.

| Variable | Purpose |
|---|---|
| `PATH` | the fallback lookup for `ffmpeg`, `ffprobe`, Chrome, Blender, `node`, Python |
| `PYTHON` | which Python the ReelMimic scripts use |
| `FFMPEG_DIR` | directory holding the FFmpeg binaries |
| `CHROME_PATH` | the Chromium/Chrome binary for `puppeteer-core` renders |
| `BLENDER` | Blender binary for `blender-product-film` |
| `REALESRGAN` | `realesrgan-ncnn-vulkan` binary |
| `HYPERFRAMES_ROOT` | a built HyperFrames checkout (see §1) |
| `HYPERFRAMES_NO_TELEMETRY`, `DO_NOT_TRACK` | disable HyperFrames telemetry (set in `shared-dependencies/.claude/settings.json`) |
| `REMOTION_TELEMETRY_DISABLED` | disable Remotion telemetry |
| `HYPERFRAMES_SKIP_SKILLS` | skip the CLI's skill-registry check during `hyperframes init` |
| `HYPERFRAMES_MEDIA_HOME` / `HYPERFRAMES_MEDIA_HOME_REQUIRED` | media cache location used by `media-use` |
| `HF_MEDIA_ENGINE` | path to the media audio engine used by `faceless-explainer`/`pr-to-video`/`product-launch-video` |
| `HF_TTS_PROVIDER` | TTS provider selection (`auto` by default; e.g. `elevenlabs`) |
| `HF_SNAPSHOT_SLOTS`, `RENDER_SLOTS`, `BULK_RENDER_SLOTS` | parallel render/snapshot concurrency |
| `TRANSCRIBE_ENGINE`, `WHISPER_MODEL`, `WHISPER_LANG`, `WHISPERX_VERSION` | transcription engine and model selection |
| `HYPERFRAMES_PARAKEET` | parakeet-mlx environment used by `media-use` transcription |
| `PR_TO_VIDEO_PROJECT_DIR` | project directory override for `pr-to-video` |
| `HEYGEN_API_KEY`, `HEYGEN_CONFIG_DIR`, `HYPERFRAMES_API_KEY` | HeyGen / HyperFrames cloud services |
| `GEMINI_API_KEY` / `GOOGLE_API_KEY`, `GOOGLE_APPLICATION_CREDENTIALS`, `GCS_CREDS`, `GCLOUD_PROJECT_ID`, `GOOGLE_CLOUD_PROJECT` | Gemini TTS/grounding and Google Cloud bulk rendering |
| `ELEVENLABS_API_KEY` | ElevenLabs TTS |
| `YATING_KEY` | Yating TTS (Taiwanese Mandarin) |
| `PIXABAY_KEY`, `FREESOUND_KEY` | stock asset search |

Upstream's `secrets.example.json` (packaged in `shared-dependencies/upstream-repo-docs/`) documents the
subset the web app reads — `YATING_KEY`, `PIXABAY_KEY`, `FREESOUND_KEY`, `FFMPEG_DIR`, `CHROME_PATH`,
`PYTHON`, `CODEX_BIN`, `CODEX_SANDBOX`. The app reads it; the skills read the environment, so export the
variables rather than relying on that file.

## 8. Recommended install sequence

```bash
# 1. Tools
node --version            # ≥ 22.18, else install Node 22 LTS
python --version          # ≥ 3.10, else install Python 3.12
ffmpeg -version           # else install FFmpeg and export FFMPEG_DIR

# 2. Python packages (upstream's list, packaged here)
python -m pip install -r shared-dependencies/requirements.txt

# 3. HyperFrames CLI (not bundled)
npx --yes hyperframes doctor

# 4. Optional: a HyperFrames checkout for embedded-captions / media-use / remotion-to-hyperframes
#    git clone https://github.com/heygen-com/hyperframes && cd hyperframes
#    bun install && bun run build && export HYPERFRAMES_ROOT=$(pwd)

# 5. Skills into a project (keeps cross-skill relative paths working)
mkdir -p /path/to/your-project/.claude
cp -r skills /path/to/your-project/.claude/skills
cp shared-dependencies/.claude/settings.json /path/to/your-project/.claude/settings.json

# 6. Per-engine template deps are installed per project, by the engine's own scaffold:
#    bash /path/to/your-project/.claude/skills/painted-animation/scripts/new_project.sh my-video
#    (then `npm ci` / `npm install` inside the scaffolded project)

# 7. An agent to run it
npm i -g @anthropic-ai/claude-code   # then run `claude` once to log in
# or: npm i -g @openai/codex && codex login
```

## 9. Limitations

- **Nothing here was executed end-to-end.** This pack was built by inspecting the repository; no
  render was run, no HyperFrames CLI was installed, no API key was used. Dependency statements above are
  derived from the skills' own commands, imports and environment reads — with the extension/command
  counts in `verification/skills-inventory.tsv` as evidence — not from a successful production run.
- **Line endings:** files were extracted from git objects, so they are byte-identical to upstream
  (LF where upstream stores LF, CRLF where upstream stores CRLF). On Windows, `core.autocrlf=true`
  checkouts will convert on the next clone—but nothing here was converted during packaging.
- **No executable bits:** no file under `.claude/skills/` is stored as `100755` upstream, so every
  `.sh` script must be invoked as `bash script.sh` (which is how the skills document them anyway).
- **Bun** is required only for building HyperFrames from source; the npm CLI path needs only Node.
- **3D track:** upstream's own rules mark the 3D track paused (`blender-product-film` is packaged but
  normally not selected), so its dependencies are included for completeness rather than as a supported path.
