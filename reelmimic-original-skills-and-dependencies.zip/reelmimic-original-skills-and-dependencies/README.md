# ReelMimic — original skills and their dependencies

This archive contains **every original skill folder from the ReelMimic repository, byte-for-byte
unmodified**, plus the supporting files that live outside `.claude/skills/` and are needed to run them.

| | |
|---|---|
| Upstream repository | <https://github.com/edenfunf/reelmimic> |
| Branch | `main` |
| Commit | `782a3ba3cfa455663127348dbfcbcfafada05d52` (2026-10-16) |
| Skills extracted | **36** (all 36 folders under `.claude/skills/`) |
| Skill files extracted | **1077** (29,302,429 bytes) |
| Skill `SKILL.md` files | **36** — one per skill folder |

Nothing inside `skills/` was rewritten, summarised, reformatted or regenerated: every file is the exact
git blob from upstream (verified by SHA-1 — see [VERIFICATION.md](VERIFICATION.md)).

## Layout

```
skills/                                 36 original skill folders, original internal layout
shared-dependencies/                    supporting files taken from the repo root / .claude
  requirements.txt                      Python packages the analysis scripts import
  skills-lock.json                      upstream source + hash of each skill (provenance)
  .claude/settings.json                 telemetry-off env vars the skills expect
  upstream-repo-docs/                   verbatim repo docs: README, TROUBLESHOOTING, AGENTS,
                                        CLAUDE, docs/EXTENDING.md, secrets.example.json, .gitattributes
licenses/                               repo LICENSE (MIT), THIRD_PARTY_NOTICES.md, Apache-2.0 text
verification/
  skills-inventory.tsv                  per-skill file/type inventory
  upstream-blob-hashes.txt              1077 upstream blob SHA-1s (original paths)
  verify-against-upstream.sh            re-run the byte-for-byte check against a clone
SOURCE_MANIFEST.md                      provenance, path mapping, what was excluded and why
ANYTHINGLLM_SETUP.md                    how to use this with AnythingLLM (knowledge vs. execution)
DEPENDENCIES.md                         required/optional software, models, APIs, per-skill needs
VERIFICATION.md                         what was checked, how, and what was not tested
```

## Quick start

These skills are plain Markdown skill folders for a coding agent (Claude Code / Codex CLI and
AnythingLLM-compatible layouts). To use them in a project, copy them back to the conventional
location, which is where every relative path inside them resolves:

```bash
mkdir -p /path/to/your-project/.claude
cp -r skills /path/to/your-project/.claude/skills
```

The cross-skill references inside the docs (for example
`../hyperframes/references/frame-worker-core.md`) resolve **only** while the 36 folders stay siblings
inside one `skills/` directory — keep them together and keep folder names as they are.

Startup entry points:

- `skills/video-clone/SKILL.md` — ReelMimic's own orchestrator (reference video → style → production plan → render).
- `skills/hyperframes/SKILL.md` and `skills/hyperframes-cli/SKILL.md` — the HyperFrames workflow and its CLI surface.
- `skills/<engine>/SKILL.md` — one file per production engine (painted-animation, anime-cel, pixel-art, paper-cutout, whiteboard, crayon-storybook, music-to-video, …).

Read [DEPENDENCIES.md](DEPENDENCIES.md) before trying to run anything: most engines need Node 22.18+,
Chrome, FFmpeg, and the `hyperframes` CLI, which is **not** bundled here because it is published
separately on npm.

## Licensing

The archive redistributes third-party skills under their original licences. `LICENSE` (MIT) covers
ReelMimic's own code; most bundled HyperFrames-derived skills are Apache-2.0 (© HeyGen, Inc.), several
engines are MIT, and bundled fonts are SIL OFL 1.1. See `licenses/THIRD_PARTY_NOTICES.md` for the full
per-path table and `licenses/README.md` for the licence files that are inside the skill folders
themselves (they were left in place, unmodified).
