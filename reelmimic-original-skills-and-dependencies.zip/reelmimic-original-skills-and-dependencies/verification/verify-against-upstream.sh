#!/usr/bin/env bash
# verify-against-upstream.sh — re-check that every packaged file still matches the upstream git blob.
#
# Usage:
#   bash verify-against-upstream.sh [path-to-reelmimic-clone]
#
# With no argument it clones the pinned commit into a temporary directory (needs network + git).
# With an argument it uses that existing clone.
#
# Why this works regardless of line endings: the check hashes the RAW bytes of each packaged file
# (git hash-object --no-filters) and compares them with the blob SHA-1 recorded in the upstream git
# index (git ls-files -s), which is exactly how upstream stores them. A checkout's own autocrlf
# conversion therefore cannot produce a false mismatch.

set -euo pipefail

REPO_URL="https://github.com/edenfunf/reelmimic.git"
PIN="782a3ba3cfa455663127348dbfcbcfafada05d52"

PACK_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
REPO="${1:-}"

if [ -z "$REPO" ]; then
  tmp="$(mktemp -d)"
  echo ">> cloning $REPO_URL @ $PIN into $tmp"
  git clone --quiet "$REPO_URL" "$tmp/reelmimic"
  REPO="$tmp/reelmimic"
fi

cd "$REPO"
head_sha="$(git rev-parse HEAD)"
echo ">> repository: $REPO"
echo ">> HEAD: $head_sha"
if [ "$head_sha" != "$PIN" ]; then
  echo "   note: HEAD is not the pinned commit $PIN; checking the local HEAD instead."
fi

# Map an upstream path to where it lives in this pack.
map_path() {
  case "$1" in
    .claude/skills/*)              echo "skills/${1#.claude/skills/}" ;;
    requirements.txt)              echo "shared-dependencies/requirements.txt" ;;
    skills-lock.json)              echo "shared-dependencies/skills-lock.json" ;;
    .claude/settings.json)         echo "shared-dependencies/.claude/settings.json" ;;
    README.md)                     echo "shared-dependencies/upstream-repo-docs/README.md" ;;
    TROUBLESHOOTING.md)            echo "shared-dependencies/upstream-repo-docs/TROUBLESHOOTING.md" ;;
    AGENTS.md)                     echo "shared-dependencies/upstream-repo-docs/AGENTS.md" ;;
    CLAUDE.md)                     echo "shared-dependencies/upstream-repo-docs/CLAUDE.md" ;;
    secrets.example.json)          echo "shared-dependencies/upstream-repo-docs/secrets.example.json" ;;
    .gitattributes)                echo "shared-dependencies/upstream-repo-docs/.gitattributes" ;;
    docs/EXTENDING.md)             echo "shared-dependencies/upstream-repo-docs/docs/EXTENDING.md" ;;
    LICENSE)                       echo "licenses/LICENSE" ;;
    THIRD_PARTY_NOTICES.md)        echo "licenses/THIRD_PARTY_NOTICES.md" ;;
    LICENSES/Apache-2.0.txt)       echo "licenses/Apache-2.0.txt" ;;
    *)                             echo "" ;;
  esac
}

checked=0
missing=0
mismatch=0
declare -a problems=()

while IFS= read -r line; do
  sha="$(printf '%s\n' "$line" | awk '{print $2}')"
  path="$(printf '%s\n' "$line" | sed 's/^[0-9]* [0-9a-f]* [0-9]*\t//')"
  rel="$(map_path "$path")"
  if [ -z "$rel" ]; then
    continue  # upstream file that this pack intentionally excludes
  fi
  target="$PACK_ROOT/$rel"
  if [ ! -f "$target" ]; then
    problems+=("MISSING  $path  (expected at $rel)")
    missing=$((missing + 1))
    continue
  fi
  actual="$(git hash-object --no-filters "$target")"
  checked=$((checked + 1))
  if [ "$actual" != "$sha" ]; then
    problems+=("MODIFIED $path  expected=$sha actual=$actual")
    mismatch=$((mismatch + 1))
  fi
done < <(git ls-files -s -- .claude/skills requirements.txt skills-lock.json .claude/settings.json \
           README.md TROUBLESHOOTING.md AGENTS.md CLAUDE.md secrets.example.json .gitattributes \
           docs/EXTENDING.md LICENSE THIRD_PARTY_NOTICES.md LICENSES/Apache-2.0.txt)

echo
echo "checked:      $checked"
echo "missing:      $missing"
echo "mismatched:   $mismatch"
if [ "${#problems[@]}" -gt 0 ]; then
  echo
  echo "problems:"
  printf '  %s\n' "${problems[@]}"
  exit 1
fi

echo
echo "OK — every packaged file is byte-identical to its upstream git blob."
