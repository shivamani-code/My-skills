#!/usr/bin/env bash
# check-local-references.sh — scan every relative path reference written inside the pack and report
# the ones whose target filename exists nowhere in the pack.
#
# A reported reference is either (a) an illustrative path quoted in prose, (b) a file that exists
# upstream but was deliberately not redistributed, or (c) a genuine missing dependency. The
# interesting set is small and is reviewed by hand in ../../VERIFICATION.md §3.
#
# Usage: bash check-local-references.sh [pack-root]

set -uo pipefail
PACK="$(cd "${1:-$(dirname "${BASH_SOURCE[0]}")/..}" && pwd)"
SKILLS="$PACK/skills"
REF_RE='\.\.(/[A-Za-z0-9_@.+-]+)+'

# Prose/placeholder paths that are not meant to exist on disk.
FILTER='(^|/)(out|my-video|etc|outside|hf-src|hf\.mp4|assets/x(\.png)?|assets/square\.png|assets/x|pulls/N/files|out/check|music-to-video|media-use|hyperframes-animation|hyperframes-creative|standard|hyperframes)$'

refs="$(grep -rhoE "$REF_RE" "$SKILLS" \
  --include='*.md' --include='*.mjs' --include='*.cjs' --include='*.js' \
  --include='*.sh' --include='*.py' --include='*.json' --include='*.html' \
  --include='*.css' --include='*.txt' 2>/dev/null | sort -u)"

total=0
unresolved=0
echo "== relative references whose target filename exists nowhere in the pack =="
while IFS= read -r ref; do
  [ -n "$ref" ] || continue
  total=$((total + 1))
  if printf '%s' "$ref" | grep -qE "$FILTER"; then continue; fi
  base="${ref##*/}"
  if ! find "$SKILLS" -name "$base" -print -quit | grep -q .; then
    echo "  $ref"
    unresolved=$((unresolved + 1))
  fi
done <<< "$refs"

echo
echo "distinct relative references scanned: $total"
echo "targets not found anywhere in the pack: $unresolved"
