# SOURCE_MANIFEST.md

Provenance, contents and exclusions for `reelmimic-original-skills-and-dependencies.zip`.

## 1. Source

| Field | Value |
|---|---|
| Repository URL | <https://github.com/edenfunf/reelmimic> |
| Original branch | `main` |
| Commit SHA | `782a3ba3cfa455663127348dbfcbcfafada05d52` |
| Commit date | Fri Oct 16 14:37:19 2026 +0800 |
| Commit subject | (HEAD of `main` at clone time; 13 further remote branches exist and were not used) |
| Repository licence | MIT (`licenses/LICENSE`) |
| Clone method | `git clone https://github.com/edenfunf/reelmimic.git` (full clone, not shallow) |
| Extraction method | `git -c core.autocrlf=false -c core.eol=lf archive --format=tar HEAD <paths>` |
| Repository files at this commit | 1179 tracked files |
| Files packaged from `.claude/skills/` | **1077 of 1077** (nothing under `.claude/skills/` was omitted) |
| Skill folders discovered | **36** — all 36 have a `SKILL.md` |
| Files packaged from outside `.claude/skills/` | 13 |

**Why `git archive` with `core.autocrlf=false`:** the checkout on the extraction host uses
`core.autocrlf=true`, so working-tree files are LF→CRLF converted. The archive was therefore streamed
straight out of the git object store with conversion disabled, so each packaged file is the exact
upstream blob. This is verified: see `verification/upstream-blob-hashes.txt` and
[VERIFICATION.md](VERIFICATION.md).

## 2. Path mapping

The only path rewrite is the one the requested layout requires. No file was renamed or re-nested.

| In this archive | Original path in the repository |
|---|---|
| `skills/<skill>/…` | `.claude/skills/<skill>/…` |
| `shared-dependencies/requirements.txt` | `requirements.txt` |
| `shared-dependencies/skills-lock.json` | `skills-lock.json` |
| `shared-dependencies/.claude/settings.json` | `.claude/settings.json` |
| `shared-dependencies/upstream-repo-docs/README.md` | `README.md` |
| `shared-dependencies/upstream-repo-docs/TROUBLESHOOTING.md` | `TROUBLESHOOTING.md` |
| `shared-dependencies/upstream-repo-docs/AGENTS.md` | `AGENTS.md` |
| `shared-dependencies/upstream-repo-docs/CLAUDE.md` | `CLAUDE.md` |
| `shared-dependencies/upstream-repo-docs/secrets.example.json` | `secrets.example.json` |
| `shared-dependencies/upstream-repo-docs/.gitattributes` | `.gitattributes` |
| `shared-dependencies/upstream-repo-docs/docs/EXTENDING.md` | `docs/EXTENDING.md` |
| `licenses/LICENSE` | `LICENSE` |
| `licenses/THIRD_PARTY_NOTICES.md` | `THIRD_PARTY_NOTICES.md` |
| `licenses/Apache-2.0.txt` | `LICENSES/Apache-2.0.txt` |

Everything under `skills/` keeps its original internal hierarchy and filenames. The skill-folder names
are unchanged, which matters because skills refer to each other by folder name (for example
`video-clone/styles/painted-story-mv.md` names the engine folder `painted-animation`, and
`faceless-explainer/scripts/frame-packets.mjs` reads `../hyperframes/references/frame-worker-core.md`).

Because that cross-skill addressing is relative to a shared parent `skills/` directory, restoring the
pack must keep the 36 folders as siblings. To use the pack inside a project, copy `skills/` to
`<project>/.claude/skills/` (`cp -r skills <project>/.claude/skills`).

## 3. Skills included (36)

All 36 folders under `.claude/skills/` at the pinned commit, each with its `SKILL.md`. File counts and
byte counts per skill are in `verification/skills-inventory.tsv`.

**ReelMimic's own skills (MIT, © ReelMimic):**
`video-clone`, `blender-product-film`, `anime-cel`, `pixel-art`, `paper-cutout`, `whiteboard`

**Bundled third-party skills, from `heygen-com/hyperframes` (Apache-2.0, © 2026 HeyGen, Inc.):**
`hyperframes`, `hyperframes-animation`, `hyperframes-audio`, `hyperframes-cli`, `hyperframes-core`,
`hyperframes-creative`, `hyperframes-keyframes`, `hyperframes-registry`, `hyperframes-studio`,
`embedded-captions`, `faceless-explainer`, `figma`, `general-video`, `media-use`, `motion-graphics`,
`music-to-video`, `pr-to-video`, `product-launch-video`, `remotion-to-hyperframes`, `slideshow`,
`talking-head-recut`, `captions-overlay`, `cut-the-curve`, `motion-doctrine`, `oversized-cursor`,
`seam-craft`

**Bundled third-party skills, from other upstreams:**
`crayon-storybook`, `painted-animation` (MIT, derived from `tuzhechen2005/painted-animation` +
`JohnHeibel/ClaudeAnimationBase`), `frontend-design` (Apache-2.0, © Anthropic), `ffmpeg`
(MIT, © 2024 Digital Samba)

The authoritative per-path licence table is upstream's own `licenses/THIRD_PARTY_NOTICES.md`, included
verbatim. `verification/skills-inventory.tsv` carries the machine-readable inventory; upstream's
`skills-lock.json` (in `shared-dependencies/`) carries each skill's upstream source repository and
`computedHash`.

## 4. Supporting files included from outside `.claude/skills/`

Included because the skills reference them, or because they are the environment/setup documentation the
workflows assume:

1. **`shared-dependencies/requirements.txt`** — the Python packages the skill scripts import
   (`video-clone/scripts/*.py`, `painted-animation/scripts/beat_grid.py`,
   `music-to-video/scripts/analyze-beatgrid.py`, `blender-product-film/scripts/*.py`, …).
2. **`shared-dependencies/skills-lock.json`** — upstream provenance + hash of each skill; needed to
   document where each skill came from and to detect drift after a re-sync.
3. **`shared-dependencies/.claude/settings.json`** — sets `HYPERFRAMES_NO_TELEMETRY=1`,
   `DO_NOT_TRACK=1`, `REMOTION_TELEMETRY_DISABLED=1`. Several skills (notably `motion-doctrine`) and
   all `npx hyperframes` / `npx remotion` invocations assume these are set; without them, CLI runs emit
   telemetry. Install it at `<project>/.claude/settings.json`.
4. **`shared-dependencies/upstream-repo-docs/`** — verbatim copies of the upstream repository's own
   setup material:
   - `README.md` — the canonical environment list (Node 22.18+, Python 3.10+, FFmpeg, Chrome, Claude Code
     or Codex CLI) and the settings/env-var table. Its screenshots live in `docs/assets/`, which is not
     packaged (see §5), so those image links are dead in this copy.
   - `TROUBLESHOOTING.md` — the wrong-Python / missing-Chrome / Codex-sandbox / port / output-location
     fixes. Directly relevant to running the skill scripts.
   - `AGENTS.md` and `CLAUDE.md` — the workspace rules; they name the skills, the file contract, and the
     env vars (`FFMPEG_DIR`, `CHROME_PATH`, `BLENDER`, `PYTHON`).
   - `secrets.example.json` — documents the environment knobs (tool paths, API keys) the render
     workflows read.
   - `.gitattributes` — records which skill folders are vendored upstream code, which is the mapping
     used to attribute licences correctly.
   - `docs/EXTENDING.md` — how styles, engines and tools plug in; referenced from the workspace rules.
5. **`licenses/`** — `LICENSE`, `THIRD_PARTY_NOTICES.md`, `Apache-2.0.txt`.

## 5. Intentionally excluded

None of the excluded paths is referenced by a packaged skill; the checks behind that statement are in
[VERIFICATION.md](VERIFICATION.md) §3.

| Excluded | Files | Why |
|---|---|---|
| `.git/` | — | VCS history and unreachable objects; not needed to run the skills |
| `app/` | 49 | The ReelMimic web application (Hono/Node server + React UI + its `package.json`, lockfile, tests, `scripts/doctor.mjs`, `restart.sh`). It is a UI/agent-harness layer, not a skill dependency: skills reference `app/` in prose only (the file contract in `projects/<id>/`). Excluded as "unrelated application UI and server components". |
| `docs/ARCHITECTURE.md`, `docs/zh-CN/**`, `docs/zh-TW/**` | 6 | Web-app architecture and its translations |
| `docs/assets/**` | 17 | README screenshots, flow diagrams and demo GIFs (2 MB of PNG/GIF/SVG) |
| `.github/**` | 7 | Issue templates, PR template, CI workflow, Claude review workflow |
| `install.sh`, `install.bat`, `start.sh`, `start.bat` | 4 | Installers/launchers for the web app (`npm install` + `npm run build` inside `app/`, then `node server/index.ts`). Nothing in them is required by a skill; the one part that *is* relevant (`pip install -r requirements.txt`, and the `npm run doctor` environment check) is documented in `DEPENDENCIES.md`. |
| `README.zh-CN.md`, `README.zh-TW.md` | 2 | Translations of the packaged `README.md` |
| `CODE_OF_CONDUCT.md`, `CONTRIBUTING.md`, `SECURITY.md` | 3 | Project governance, not skill material |
| `projects/.gitkeep` | 1 | Placeholder for the runtime output directory (`projects/<id>/out/video.mp4`). Runtime data, not skill content; skills create it themselves. |
| `.gitignore` | 1 | Repository-level ignore rules for the web app; the two skill-level ignore rules that matter (`.claude/skills/*/.gitignore`) are packaged inside their skills |

## 6. Referenced but not present in the source repository

These are real dependencies that upstream itself does not ship. They are listed here, described in
[DEPENDENCIES.md](DEPENDENCIES.md), and were **not** silently dropped:

1. **The HyperFrames CLI and player bundles** — `packages/cli/dist/cli.js`,
   `packages/cli/src/**`, `packages/player/dist/hyperframes-player.global.js`,
   `packages/player/dist/slideshow/hyperframes-slideshow.global.js`. Referenced by
   `embedded-captions/scripts/render-and-composite.sh`, `media-use/scripts/resolve.mjs`,
   `remotion-to-hyperframes/assets/test-corpus/run.sh`, `remotion-to-hyperframes/references/eval.md`,
   `slideshow/references/standalone-harness.md` and dozens of `npx hyperframes …` command lines.
   Installed separately from npm as the `hyperframes` package (`npx hyperframes …`); the repo only ever
   points at a checkout of it.
2. **The upstream component registry** — `registry/components/motion-blur/motion-blur.html` (named in
   `hyperframes-animation/references/motion-blur.md`) and the block/component tree described in
   `hyperframes-registry/references/contributing.md`. Lives in the upstream HyperFrames monorepo and is
   reached with `npx hyperframes add <block|component>` / `npx hyperframes catalog`.
3. **Pixabay sound effects** — `media-use/audio/assets/sfx/*.mp3`. Deliberately not redistributed
   upstream (Pixabay Content License forbids passing the files on as standalone files). The directory is
   packaged with its `CREDITS.md` and `manifest.json`; see §7.
4. **The matting model** — `u2net_human_seg.onnx`. `embedded-captions/.gitignore` still contains a
   comment claiming `assets/ppmattingv2_stdc1_human_544x960.onnx` "ships with the skill", but **no
   `.onnx` file exists in the repository at this commit** (checked: zero tracked, zero on disk).
   `embedded-captions/scripts/matte.cjs` instead calls `hyperframes remove-background`, which downloads
   `u2net_human_seg.onnx` (~168 MB) into `~/.cache/hyperframes/background-removal/models/` on first run.
5. **Twelve Remotion skills** — `remotion-best-practices`, `remotion-captions`, `remotion-create`,
   `remotion-docs`, `remotion-interactivity`, `remotion-maps`, `remotion-markup`,
   `remotion-multimedia`, `remotion-render`, `remotion-saas`, `remotion-studio`, `remotion-upgrade`.
   Pinned in `skills-lock.json` (source `remotion-dev/skills`) but not distributed by upstream for
   licensing reasons; they are unrelated to the 36 packaged skills. `video-clone/styles/remotion-react.md`
   expects one of them, so that one style cannot be used from this pack alone.
6. **`_vendor/` clones** — upstream notes that local `_vendor/` reference clones are never published.
   They are not part of this repository, so nothing from them could be packaged.
7. **`app/scripts/doctor.mjs` and `npm run doctor`** — the environment checker lives in the excluded web
   app. `DEPENDENCIES.md` lists the same checks so they can be performed by hand.

## 7. Runtime assets and outputs that are not packaged

- The `media-use` and `embedded-captions` workflows write into the *user's project*, not into the skill
  folder (upstream even gitignores `*.mp4`, `*.webm`, `frames_bg/`, `transcript.json`, `plan.json`,
  `safe-zones.json` inside `embedded-captions`). No rendered output, caches, `node_modules`, or
  `~/.cache/hyperframes` content is included.
- `package-lock.json` files that upstream tracks inside skill templates (`anime-cel`, `crayon-storybook`,
  `painted-animation`, `paper-cutout`, `pixel-art`, `whiteboard`) **are** included, so `npm ci` inside a
  scaffolded project reproduces the template dependency tree. `node_modules` is not included.

## 8. Content integrity

- Extracted files: **1077 / 1077** match their upstream git blob SHA-1 byte-for-byte
  (`verification/upstream-blob-hashes.txt`).
- The 13 supporting files were extracted the same way; their blob hashes were verified in the same run.
- No file was edited after extraction. The only additions are the packaging documents named on the
  title page of [README.md](README.md), `verification/` metadata, and
  `verification/verify-against-upstream.sh` (a re-verification helper written for this pack).
- Skill content was not rewritten, summarised or regenerated anywhere. Platform notes (AnythingLLM) are
  kept in the separate `ANYTHINGLLM_SETUP.md`, per the requirement not to rewrite skills for a platform.
