# ReelMimic Original Skills ZIP downloader
# Downloads the official source archive and packages the exact original skills.
# No skills are generated or modified by this script.

$ErrorActionPreference = "Stop"
$repoZipUrl = "https://github.com/edenfunf/reelmimic/archive/refs/heads/main.zip"
$tempRoot = Join-Path $env:TEMP ("reelmimic-extract-" + [guid]::NewGuid().ToString("N"))
$downloadZip = Join-Path $tempRoot "reelmimic-main.zip"
$extractDir = Join-Path $tempRoot "repo"
$downloads = Join-Path $env:USERPROFILE "Downloads"
$skillsZip = Join-Path $downloads "reelmimic-original-skills.zip"
$fullZip = Join-Path $downloads "reelmimic-complete-source.zip"

try {
    New-Item -ItemType Directory -Path $tempRoot -Force | Out-Null
    New-Item -ItemType Directory -Path $downloads -Force | Out-Null

    Write-Host "Downloading the official ReelMimic source from GitHub..." -ForegroundColor Cyan
    Invoke-WebRequest -Uri $repoZipUrl -OutFile $downloadZip -UseBasicParsing

    Write-Host "Extracting source archive..." -ForegroundColor Cyan
    Expand-Archive -LiteralPath $downloadZip -DestinationPath $extractDir -Force
    $repoRoot = Get-ChildItem -LiteralPath $extractDir -Directory | Select-Object -First 1
    if (-not $repoRoot) { throw "Could not locate extracted repository folder." }

    $skillsDir = Join-Path $repoRoot.FullName ".claude\skills"
    if (-not (Test-Path -LiteralPath $skillsDir)) { throw "Original .claude\skills folder not found." }

    if (Test-Path -LiteralPath $skillsZip) { Remove-Item -LiteralPath $skillsZip -Force }
    if (Test-Path -LiteralPath $fullZip) { Remove-Item -LiteralPath $fullZip -Force }

    # Package the exact skill tree plus the repository license and notices.
    $stage = Join-Path $tempRoot "skills-package"
    New-Item -ItemType Directory -Path (Join-Path $stage ".claude") -Force | Out-Null
    Copy-Item -LiteralPath $skillsDir -Destination (Join-Path $stage ".claude\skills") -Recurse
    foreach ($file in @("LICENSE", "THIRD_PARTY_NOTICES.md", "README.md")) {
        $source = Join-Path $repoRoot.FullName $file
        if (Test-Path -LiteralPath $source) { Copy-Item -LiteralPath $source -Destination $stage }
    }
    Compress-Archive -Path (Join-Path $stage "*"), (Join-Path $stage ".claude") -DestinationPath $skillsZip -CompressionLevel Optimal -Force

    # Also keep the official full repository archive, for the scripts/app/templates
    # that the skills may reference. This is an exact archive of the downloaded repo.
    Copy-Item -LiteralPath $downloadZip -Destination $fullZip -Force

    Write-Host ""
    Write-Host "DONE" -ForegroundColor Green
    Write-Host "Original skills + license notices: $skillsZip"
    Write-Host "Complete original source repository: $fullZip"
    Write-Host "No new or rewritten skills were created."
    Write-Host ""
    Write-Host "Note: AnythingLLM knowledge uploads alone do not execute scripts. Rendering requires a local tool/agent runtime and the dependencies documented by ReelMimic."
}
catch {
    Write-Error ("Failed: " + $_.Exception.Message)
    Write-Host "Check your internet connection and try again. Source: https://github.com/edenfunf/reelmimic"
    exit 1
}
finally {
    if (Test-Path -LiteralPath $tempRoot) {
        Remove-Item -LiteralPath $tempRoot -Recurse -Force -ErrorAction SilentlyContinue
    }
}
