@echo off
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0download_reelmimic_original_skills.ps1"
echo.
pause
