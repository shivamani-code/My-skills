# 🌌 AI-DEV-KIT: Agentic System Development Standards

This document establishes the official coding, architecture, security, testing, and deployment standards for our full-stack SaaS applications built with **Next.js 15, React 19, TypeScript, Tailwind CSS, Node.js, PostgreSQL, and Supabase**. All agents and human developers must adhere to these directives.

---

## 💻 1. Coding Standards

### TypeScript & JavaScript
- **Strict Mode**: Enable strict mode in `tsconfig.json`. Explicit type definitions are required for public-facing API signatures, function parameters, and return types. Avoid the `any` type at all costs; use `unknown` or custom interfaces instead.
- **Imports**: Organize imports cleanly. Place Node built-ins first, third-party libraries second, and local project paths last. Use absolute path aliasing (`@/components/...`) instead of deeply nested relative paths (`../../../../components/...`).

### React 19 & Next.js 15
- **Next.js App Router**: Build pages using the App Router model. Keep routes clean and delegate all layout rendering logic to sub-components.
- **Server Components by Default**: Place components in server space to minimize the JavaScript sent to the client. Restrict `"use client"` directives strictly to files that implement event handlers, client hooks (`useState`, `useEffect`), or Framer Motion animation triggers.
- **State Management**: Prefer server-side URL states (e.g. query params) or Server Action responses. Use local React state or context stores only when local UI synchronization is required.

### Tailwind CSS (v4/v3)
- **Design Token Mapping**: Rely strictly on classes mapped to design system variables (e.g., `bg-background`, `text-primary`, `border-border`). Do not write arbitrary values (`bg-[#123456]`) in component files; define custom colors inside Tailwind config files.
- **Responsiveness**: Always use responsive mobile-first grid and flex configurations (`grid grid-cols-1 md:grid-cols-3`). Test layout layouts across various breakpoints.

---

## 🏛️ 2. Architecture Standards

- **Layered Boundary Isolation**: Isolate the database models and network API routes from frontend layout views. Next.js page files should act only as routers and view binders; place data query actions inside dedicated modules under `@/lib/modules/...`.
- **Domain-Driven Design (DDD)**: Group resources by functional domain (e.g. Users, Billing, Workspaces). Define distinct entities, aggregates, and value objects with clear invariant rules. Keep domains decoupled; use public helper methods or domain events to sync data across domains.
- **API Contracts**: Structure API responses uniformly. Return `{ success: true, data: [...] }` on success, and `{ success: false, error: { code: '...', message: '...' } }` on failure.

---

## 🔒 3. Security Standards

- **OWASP Compliance**: Protect all user entries against SQL Injection, XSS, and Cross-Site Request Forgery (CSRF). Parameterize all database queries (using Drizzle/Prisma). Sanitize input values and rich-text markup prior to DOM injection.
- **Authentication & Authorization**: Enable secure cookie configurations (`httpOnly: true`, `secure: true`, `sameSite: "strict"`). Never trust client-side local storage parameters for authorization validation; always query user credentials and workspace ownership on the server.
- **Row-Level Security (RLS)**: Enforce RLS on all user-facing PostgreSQL tables. Every query fetch must scope database access using tenant constraints (`workspace_id` or `user_id`).
- **Secrets Management**: Load all configurations from secure environment variables (`.env`). Never commit private keys, API secrets, or passwords to source control.

---

## 🧪 4. Testing Requirements

- **Test Isolation**: Write tests that isolate components and services. Mock network requests using MSW (Mock Service Worker) instead of monkey-patching global fetch arrays.
- **E2E Testing (Playwright)**: Write E2E browser scenarios for business-critical workflows (Signup, Onboarding, Subscription Billing, Core Application Workspaces). Implement the Page Object Model (POM) pattern to separate selectors from test execution steps.
- **Quality Gates**: Enforce pre-commit hooks (Husky) to execute fast linter, typecheck, and unit testing runs. Reject any pull request that reduces coverage or breaks existing verification runs in the pipeline.

---

## 🚀 5. Deployment Requirements

- **Hardened Multi-Stage Docker builds**: Containerize applications using clean multi-stage builds. Extract build dependencies to builder stages, leaving only standalone runner runtimes in production containers.
- **Non-Root Execution**: Never launch Docker processes as `root`. Declare a custom system user and group (`nextjs:nodejs`), and invoke processes using the `USER nextjs` directive.
- **CI/CD Pipelines**: Automate code compilation, test suite execution, security audits, and deploy steps. Establish multi-stage approval gates (e.g., manual approval flags for production releases).

---

## 🔍 6. Code Review Requirements

- **Clean Code Principles**: Refactor methods that grow beyond 30 lines. Enforce clear naming conventions, extract magic constants, and eliminate duplicate copy-paste blocks.
- **Constructive Review Loop**: Ensure PR reviews focus on design patterns, logic safety, database query speeds, and safety constraints. Lint and style checks must be automated; do not spend review time on formatting issues.
