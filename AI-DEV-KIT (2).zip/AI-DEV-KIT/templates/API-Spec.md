# API Specification: [Service Name]

## 1. Global Configurations
- **Base URL**: `/api/v1` or local routing routes.
- **Authentication**: Bearer Token (JWT) or Session Cookie.
- **Headers Required**:
  - `Content-Type: application/json`
  - `x-workspace-id: [uuid]` (Required for multi-tenant route calls)

---

## 2. API Endpoint Manifest

### 🌐 POST `/workspaces/[id]/items`
Creates a new resource item inside a tenant workspace.

#### Authentication & Scopes
- **Auth Mode**: Active Session Cookie required.
- **Required Role**: `admin` or `member`.

#### Path Parameters
- `id` (string, UUID): The unique identifier of the workspace.

#### Request Body Schema
- **Content Type**: `application/json`
- **Schema (TypeScript/Zod definition)**:
  ```typescript
  import { z } from "zod";
  export const createItemSchema = z.object({
    title: z.string().min(1).max(100),
    description: z.string().optional(),
    tags: z.array(z.string()).max(10).optional(),
  });
  ```
- **Example Payload**:
  ```json
  {
    "title": "Launch Marketing Campaign",
    "description": "Prepare graphics and copy-writing for launch.",
    "tags": ["marketing", "q3-goals"]
  }
  ```

#### Response Schemas
##### 🟢 `201 Created`
Returned when the resource has been successfully created.
- **Content Type**: `application/json`
- **Body Example**:
  ```json
  {
    "success": true,
    "data": {
      "id": "1a2b3c4d-5e6f-7a8b-9c0d-1e2f3a4b5c6d",
      "workspaceId": "8f8b8c8d-8e8f-8a8b-8c8d-8e8f8a8b8c8d",
      "title": "Launch Marketing Campaign",
      "description": "Prepare graphics and copy-writing for launch.",
      "tags": ["marketing", "q3-goals"],
      "status": "pending",
      "createdAt": "2026-06-05T22:36:00.000Z",
      "updatedAt": "2026-06-05T22:36:00.000Z"
    }
  }
  ```

##### 🔴 `400 Bad Request`
Returned when input payload fails Zod validation.
- **Body Example**:
  ```json
  {
    "success": false,
    "error": {
      "code": "VALIDATION_FAILED",
      "message": "Input validation failed.",
      "details": [
        {
          "field": "title",
          "issue": "String must contain at least 1 character(s)"
        }
      ]
    }
  }
  ```

##### 🔴 `403 Forbidden`
Returned when user authentication succeeds, but the user does not possess active membership or the correct role in the tenant workspace.
- **Body Example**:
  ```json
  {
    "success": false,
    "error": {
      "code": "INSUFFICIENT_PERMISSIONS",
      "message": "You do not have access to mutate items in this workspace."
    }
  }
  ```

---

## 3. Global Error Registry
These are unified error envelopes sent back by middleware routes:

| HTTP Status | Error Code | Reason |
| :--- | :--- | :--- |
| `401` | `UNAUTHORIZED` | Expired or missing session token. |
| `404` | `NOT_FOUND` | The requested resource or URL path does not exist. |
| `429` | `RATE_LIMIT_EXCEEDED` | Request count breached client window limits. |
| `500` | `INTERNAL_SERVER_ERROR` | An unhandled exception occurred on the server. |
