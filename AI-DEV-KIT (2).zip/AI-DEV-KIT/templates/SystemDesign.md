# System Design Document: [Project/Feature Name]

## 1. System Overview & Architecture
[Provide a high-level summary of the architectural changes introduced by this feature.]

### Architecture Diagram
```mermaid
graph TD
    Client[Next.js Client / App Router]
    Auth[Supabase Auth]
    API[Next.js Route Handlers / Server Actions]
    DB[(PostgreSQL Database)]
    Redis[(Redis Cache)]
    Stripe[Stripe API Gate]

    Client -->|Verify Auth| Auth
    Client -->|Mutations / Actions| API
    API -->|Read/Write RLS| DB
    API -->|Session / Rate Limit| Redis
    API -->|Webhook Sync| Stripe
```

---

## 2. Component Layout & Modular boundaries
Describe how the feature fits into our modular folders (`@/lib/modules/...`):

- **UI Components**: Place in `components/[feature]` or `app/[route]/components/`.
- **Server Actions**: Define inside `@/lib/modules/[feature]/actions.ts`.
- **Database Access / Queries**: Query data within `@/lib/modules/[feature]/db.ts`.

---

## 3. Data Model & PostgreSQL Schemas
Define the tables, indexes, constraints, and Row-Level Security (RLS) policies.

```sql
-- Schema Migration Draft
CREATE TABLE [table_name] (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  workspace_id uuid NOT NULL REFERENCES workspaces(id) ON DELETE CASCADE,
  status text NOT NULL DEFAULT 'draft',
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

-- Performance: Always index foreign keys
CREATE INDEX idx_[table_name]_workspace_id ON [table_name](workspace_id);

-- Security: Row Level Security Policies
ALTER TABLE [table_name] ENABLE ROW LEVEL SECURITY;

CREATE POLICY user_access_policy ON [table_name]
  FOR ALL
  USING (workspace_id IN (
    SELECT id FROM workspaces WHERE user_id = auth.uid()
  ));
```

---

## 4. Key Data Flows & Webhooks
### Sequence: [e.g. Workspace Subscription Billing Cycle]
1. **User Action**: Client submits purchase via Stripe Checkout.
2. **External Event**: Stripe fires `checkout.session.completed` event.
3. **Route Handler**: `/api/webhooks/stripe` intercepts post, verifies signature using `STRIPE_WEBHOOK_SECRET`.
4. **Transaction**: Service Action updates the local database subscription status under a transaction write lock.
5. **UI Update**: Subscribed state is updated, Client displays confirmation toast.

---

## 5. Security & Isolation Boundaries
- **Tenant Isolation**: Explain how cross-tenant access is prevented (e.g. RLS policies, checking `workspace_id` parameters in Express middleware).
- **Data Protection**: Are sensitive values encrypted? (e.g. AES-256 for API secret keys stored in DB).
- **Authentication**: Gated behind JWT/Session checks.

---

## 6. Scaling, Caching & Performance Considerations
- **Caching**: Describe cache invalidate rules (e.g. Redis key TTLs, Next.js tags like `revalidateTag`).
- **Database Performance**: Query plans check (`EXPLAIN ANALYZE`). Index placements for search terms.
- **Bundle Optimization**: Dynamic imports (`next/dynamic`) for heavy interactive charts/modals.
