# Backend Engineer Skill: Production Node.js, REST APIs & Express/Route Handlers

## 🎯 Selective Reading Rule
Use this skill when you are implementing backend API routes, writing controllers, handling business logic, configuring middleware, parsing file uploads, or creating external integrations.

## 🧠 Core Philosophy
A production-grade backend service must be resilient, secure, self-documenting, and fast. Every endpoint must validate input data, return structured response objects, handle errors gracefully without leaking stack traces, and enforce authentication and authorization scopes.

---

## 🛠️ REST Endpoint Implementation Flow

When creating or modifying an API endpoint (e.g. inside a Next.js Route Handler or Express router):

### Step 1: Input Validation
Use a validation library like `zod` to inspect query params, route params, and the body. Return `400 Bad Request` if parsing fails.
```typescript
import { z } from "zod";

const createWorkspaceSchema = z.object({
  name: z.string().min(3).max(50),
  slug: z.string().toLowerCase().regex(/^[a-z0-9-]+$/),
});

export async function POST(req: Request) {
  try {
    const json = await req.json();
    const payload = createWorkspaceSchema.parse(json);
    // ... logic
  } catch (error) {
    if (error instanceof z.ZodError) {
      return Response.json({ success: false, errors: error.errors }, { status: 400 });
    }
    return Response.json({ success: false, message: "Internal Server Error" }, { status: 500 });
  }
}
```

### Step 2: Auth and Tenant Gate
Validate the user session and permission scope before executing domain operations. For tenant-isolated SaaS, ensure all operations are restricted by `tenant_id` or `workspace_id`.
```typescript
const session = await getSession();
if (!session?.userId) {
  return Response.json({ success: false, message: "Unauthorized" }, { status: 401 });
}
```

### Step 3: Service Execution
Delegate core logic to a Service or Action class. Do not put business computations directly in route files.

### Step 4: Transaction & Database Safety
Wrap multi-step writes in a database transaction to maintain consistency.

### Step 5: Uniform Response
Return appropriate HTTP status codes:
- `200 OK` / `201 Created` for successes.
- `400 Bad Request` for validation failures.
- `401 Unauthorized` for missing/expired session tokens.
- `403 Forbidden` for insufficient permissions.
- `404 Not Found` for missing resources.
- `429 Too Many Requests` for rate limit breaches.
- `500 Internal Server Error` for unhandled system errors.

---

## 🔒 Security Guidelines for Backend Developers

1. **Input Sanitization**: Strip dangerous characters to prevent XSS and SQL Injection (rely on parameters in queries or ORMs).
2. **Rate Limiting**: Apply limit rules to critical routes (auth, login, signup, passwords) using middleware.
3. **CORS Configuration**: Restrict allowable origins for requests. Do not use wildcard `*` for authenticated APIs.
4. **Secret Management**: Never commit API keys, tokens, or private certificates to source control. Load from environment variables (`process.env.STRIPE_SECRET_KEY`).
5. **No Stack Trace Leaks**: Ensure that in production mode, internal database messages or codebase files are not exposed in the response payload.

---

## ⚠️ Backend Anti-Patterns to Avoid
* **Floating Promises**: Forgetting to use `await` on async functions or missing catch blocks, which can crash the Node.js process.
* **Direct Database Queries in Route Files**: Bypassing application validation layers, making testing and modular updates extremely difficult.
* **Insecure Route Parameters**: Relying solely on `id` from the URL parameter to update resources without confirming if the authenticated user owns that specific resource.
* **Synchronous File Operations**: Using synchronous file methods (`readFileSync`, `writeFileSync`) which block the single-threaded event loop. Use async file paths instead.
