# Frontend Engineer Skill: Premium UI/UX, React 19, Next.js 15 & Accessibility

## 🎯 Selective Reading Rule
Use this skill when you are writing React components, styling pages using Tailwind CSS, implementing transitions or animations, and reviewing or fixing user interfaces for accessibility (a11y) and responsiveness.

## 🧠 Core Philosophy
A premium SaaS interface must feel fast, responsive, and gorgeous. Never rely on generic default styling. Build interactive states with smooth hover effects, micro-animations, and responsive layouts. Ensure accessibility is baked in from the start: semantic HTML, proper contrast ratios, keyboard navigation, and full screen-reader compliance.

---

## 🎨 Design Tokens & Tailwind CSS Guidelines

### 1. Curated Dark Theme Palette
Use CSS variables mapped to Tailwind colors. Prefer refined neutral scales and vibrant accents:
- **Background**: Neutral dark (e.g., `#09090b` or HSL `240 10% 3.9%`).
- **Surface**: Glassmorphism or Card dark (e.g., `#18181b` or HSL `240 5.8% 9%`).
- **Border**: Subtle borders (e.g., `rgba(255, 255, 255, 0.08)` or HSL `240 5.9% 15%`).
- **Primary Accent**: Energetic indigo or violet (e.g., HSL `263.4 70% 50.4%`).
- **Text Primary**: Off-white (e.g., HSL `0 0% 98%`).
- **Text Secondary**: Muted gray (e.g., HSL `240 5% 64.9%`).

### 2. Glassmorphism Card Style
Use background blurs and border highlights to create a premium depth effect:
```tsx
export function GlassCard({ children, className = "" }: { children: React.ReactNode; className?: string }) {
  return (
    <div className={`rounded-xl border border-white/5 bg-zinc-900/60 backdrop-blur-md shadow-xl transition-all duration-300 hover:border-white/10 ${className}`}>
      {children}
    </div>
  );
}
```

---

## ⚡ React 19 & Next.js 15 UI Patterns

### 1. Loading States & Suspense
Always provide skeleton screens or premium loaders for asynchronous client-side operations:
```tsx
export function SkeletonRow() {
  return (
    <div className="flex animate-pulse space-x-4 py-3">
      <div className="h-10 w-10 rounded-full bg-zinc-800"></div>
      <div className="flex-1 space-y-2 py-1">
        <div className="h-4 rounded bg-zinc-800 w-3/4"></div>
        <div className="h-4 rounded bg-zinc-800 w-1/2"></div>
      </div>
    </div>
  );
}
```

### 2. Error Boundary
Wrap critical page components in React Error Boundaries to prevent a single component crash from breaking the entire application.

### 3. Server vs Client Component Boundaries
- **Server Components**: Default choice. Use for page layouts, static content, and direct database/API fetching. Keeps JavaScript bundles small.
- **Client Components** (`'use client'`): Use only when adding interactivity (states, hooks like `useState`, `useEffect`, event listeners, framer-motion animations).

---

## ♿ Accessibility (a11y) & WCAG 2.2 AA Compliance

1. **Semantic HTML**: Use `<header>`, `<nav>`, `<main>`, `<section>`, `<footer>`, `<button>`, and `<a>` appropriately. Do not use `div` for buttons.
2. **Keyboard Accessibility**: Ensure all interactive elements can be focused using the `Tab` key and triggered using `Enter` or `Space`.
3. **Focus Management**: When modals or dialogs open, trap the focus within the modal and restore it back to the trigger button upon closing.
4. **Contrast & Text Sizes**: Keep text contrast above `4.5:1` for regular text and `3:1` for large text. Use descriptive alternative text (`alt`) for images.
5. **Aria Labels**: For icon-only buttons, always supply an `aria-label`:
   ```tsx
   <button aria-label="Close settings pane" onClick={onClose} className="p-2 hover:bg-zinc-800 rounded-md">
     <CloseIcon className="h-5 w-5" />
   </button>
   ```

---

## ⚠️ UI/UX Anti-Patterns to Avoid
* **Layout Shifts (CLS)**: Resizing elements asynchronously (like loading images without dimensions or adding lists dynamically without spacer skeletons).
* **Vague Focus Rings**: Hiding the browser focus outline (`focus:outline-none`) without replacing it with a custom, highly visible focus ring (`focus-visible:ring-2 focus-visible:ring-violet-500`).
* **Non-Responsive Breakpoints**: Designing only for desktop and hardcoding width classes (`w-[1200px]`). Always use responsive prefixes (`sm:`, `md:`, `lg:`, `xl:`).
* **Color-Only Meanings**: Communicating error, warning, or success states *only* using color. Always accompany with text or descriptive icons for color-blind users.
