# Security Auditor Skill: OWASP Compliance, Threat Modeling & Secure Auth

## 🎯 Selective Reading Rule
Use this skill when you are reviewing source code for security flaws, conducting threat modeling exercises, auditing API authentication, and inspecting database constraints or environments for secret leakages.

## 🧠 Core Philosophy
Security is not an afterthought; it is a build requirement. A security auditor systematically maps attack surfaces, flags logical loopholes, ensures data isolation is ironclad, and validates code configurations against the OWASP Top 10 guidelines. Every entry point is untrusted until proven safe.

---

## 🔒 Security Operational Modes

When invoked, choose the correct analysis lens:

1. **`Audit` (Static Code Scan)**: Scan code for secret leaks (API keys, passwords), incorrect CORS configurations, XSS vectors, and RLS omissions.
2. **`Threat-Model`**: Analyze architecture using STRIDE (Spoofing, Tampering, Repudiation, Information Disclosure, Denial of Service, Elevation of Privilege) to identify design vulnerabilities before coding.
3. **`Approve/Gate`**: Run during PR reviews. Check changes against compliance gates: "Does this PR introduce new dependencies?", "Are all database updates accompanied by safe RLS policy scripts?"

---

## 🛡️ OWASP Top 10 SaaS Audit Guide

### 1. Broken Object Level Authorization (BOLA / IDOR)
- **Check**: Are database fetches filtering by both resource ID and the logged-in user's tenant ID?
- **Flaw**: `db.select().from(documents).where(eq(documents.id, inputId))`
- **Fix**: `db.select().from(documents).where(and(eq(documents.id, inputId), eq(documents.workspaceId, userWorkspaceId)))`

### 2. Broken Authentication
- **Check**: Are password reset flows securely verifying tokens? Are login routes rate-limited?
- **Fix**: Implement multi-factor authentication (MFA) hooks and use cryptographically secure random tokens with low expiration limits (15 minutes).

### 3. Sensitive Data Exposure & Cryptography
- **Check**: Are database passwords, API keys, or JWT private keys stored in code?
- **Fix**: Load all configurations from environment variables. Encrypt sensitive user data (e.g. access tokens, keys) in the database using pgCrypto or application-level AES-256-GCM.

### 4. Injection (SQL, XSS)
- **Check**: Are raw queries built with string interpolation?
- **Fix**: Use typed ORMs (Drizzle/Prisma) or parameterized queries. Sanitize client-rendered rich text output using libraries like `dompurify`.

---

## ⚡ Secure Authentication & Session Standards

* **Password Hashing**: Always hash passwords using Argon2id or bcrypt (cost factor >= 12).
* **JWT Token Security**: If using JWTs, sign them using asymmetric algorithms (RS256/ES256) and set short lifetimes (e.g., 15 minutes).
* **Cookie Attributes**: Always configure session cookies with security flags:
  ```javascript
  res.cookie("session_token", token, {
    httpOnly: true,     // Prevents client-side JS access (XSS defense)
    secure: true,       // Ensures cookie is sent over HTTPS only
    sameSite: "strict", // Protects against Cross-Site Request Forgery (CSRF)
  });
  ```

---

## ⚠️ Security Anti-Patterns to Avoid
* **Trusting Client-Side Metadata**: Using user role flags received from client-side local storage to gate admin panels or endpoints.
* **Exposing Git Directories**: Deploying `.git`, `.env`, or configuration backups to public root directory servers.
* **Default Database Permissions**: Connecting backend applications using the PostgreSQL `superuser` user (`postgres`) instead of a constrained user with limited table grants.
* **Missing CSP Headers**: Omitting Content Security Policy (CSP) headers, which allow malicious scripts to fetch assets from unauthorized CDNs.
