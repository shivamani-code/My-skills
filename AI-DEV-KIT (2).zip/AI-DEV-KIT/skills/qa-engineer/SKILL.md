# QA Engineer Skill: Test Automation, Jest/Vitest, Playwright & Quality Gates

## 🎯 Selective Reading Rule
Use this skill when you are writing unit tests, scaffolding Playwright E2E browser tests, configuring mock responses, or setting up test automation pipelines.

## 🧠 Core Philosophy
Testing provides the confidence to move fast without breaking features. A QA engineer builds resilient test suites, avoiding flaky tests and brittle assertions. Focus tests on real user behavior rather than framework implementation details. Enforce strict Quality Gates in CI/CD pipelines to catch regressions before they reach staging or production.

---

## 🧪 Unit & Integration Testing Standards (Jest / Vitest)

### 1. Mocking APIs (MSW - Mock Service Worker)
Do not mock fetch globally using string matches. Use MSW to intercept network requests at the network level:
```typescript
import { http, HttpResponse } from "msw";
import { setupServer } from "msw/node";

const server = setupServer(
  http.get("https://api.saasapp.com/v1/user", () => {
    return HttpResponse.json({ id: "user_123", name: "Alice" });
  })
);

beforeAll(() => server.listen());
afterEach(() => server.resetHandlers());
afterAll(() => server.close());
```

### 2. Test Factories for Clean Data
Use factory patterns to generate predictable test mock objects:
```typescript
export function makeUserMock(overrides = {}) {
  return {
    id: "user-" + Math.random().toString(36).substring(2, 9),
    email: "test@example.com",
    role: "user",
    createdAt: new Date().toISOString(),
    ...overrides,
  };
}
```

---

## 🌐 End-to-End (E2E) Browser Testing (Playwright)

Use Playwright to execute full user flows (sign up, workspaces, payment gates).

### 1. Page Object Model (POM)
Keep tests clean by encapsulating UI selectors and actions in Page Objects:
```typescript
// pages/login-page.ts
import { Page } from "@playwright/test";

export class LoginPage {
  constructor(private page: Page) {}

  async navigate() {
    await this.page.goto("/login");
  }

  async login(email: string, pass: string) {
    await this.page.fill('input[type="email"]', email);
    await this.page.fill('input[type="password"]', pass);
    await this.page.click('button[type="submit"]');
  }
}
```

### 2. Best Match Selectors
Avoid fragile CSS paths (`div > ul > li:nth-child(2)`). Prefer accessible role selectors:
```typescript
// Correct selector practices
await page.getByRole("button", { name: "Submit application" }).click();
await page.getByLabel("Email Address").fill("user@saas.com");
```

---

## 🤖 CI/CD Testing Integration & Gates

- **Pre-commit Hooks**: Run fast linting and unit tests locally (e.g. using `husky` + `lint-staged`).
- **Pipeline Execution**: Execute full unit, integration, and a subset of smoke E2E tests on every Pull Request.
- **Fail Fast**: Design jobs to run concurrently and fail immediately if static checks (linter, types, formats) fail.

---

## ⚠️ QA Anti-Patterns to Avoid
* **Flaky Sleep Statements**: Using `await page.waitForTimeout(3000)` to wait for elements to load. Use state assertions instead: `await expect(page.locator('#success')).toBeVisible()`.
* **Testing Internal State**: Accessing component state directly in tests instead of interacting with the DOM elements that the user sees.
* **Testing Third-Party Integrations Live**: Running E2E tests that send real API calls to Stripe or SendGrid sandbox servers in every check. Mock the APIs or run simulated local endpoints.
* **Brittle Mocks**: Mocking too many layers, resulting in passing tests that fail when deployed due to signature mismatch.
