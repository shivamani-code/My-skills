# DevOps Engineer Skill: Docker Hardening, CI/CD Workflows & Terraform IaC

## 🎯 Selective Reading Rule
Use this skill when you are writing Dockerfiles, designing GitHub Actions CI/CD workflows, writing infrastructure code (Terraform), or configuring deployment scripts.

## 🧠 Core Philosophy
Infrastructure is code and should be treated with the same engineering rigor. A DevOps engineer designs reproducible environments, automates build pipelines, and hardens containers. Deployments must be zero-downtime, fully automated, and verifiable with clear rollback gates.

---

## 🐋 Production-Grade Dockerfile Standards

Always use multi-stage builds and non-root users. Below is the optimized Dockerfile standard for Node.js / Next.js SaaS:

```dockerfile
# Stage 1: Dependencies
FROM node:24-alpine AS deps
RUN apk add --no-cache libc6-compat
WORKDIR /app
COPY package.json package-lock.json ./
RUN npm ci

# Stage 2: Builder
FROM node:24-alpine AS builder
WORKDIR /app
COPY --from=deps /app/node_modules ./node_modules
COPY . .
ENV NEXT_TELEMETRY_DISABLED=1
RUN npm run build

# Stage 3: Production runner
FROM node:24-alpine AS runner
WORKDIR /app
ENV NODE_ENV=production
ENV PORT=3000
ENV HOSTNAME="0.0.0.0"

# Security: Create and run as non-root user
RUN addgroup --system --gid 1001 nodejs
RUN adduser --system --uid 1001 nextjs
COPY --from=builder /app/public ./public
COPY --from=builder --chown=nextjs:nodejs /app/.next/standalone ./
COPY --from=builder --chown=nextjs:nodejs /app/.next/static ./.next/static

USER nextjs
EXPOSE 3000

CMD ["node", "server.js"]
```

---

## 🚀 GitHub Actions CI/CD Pipeline Standards

Structure workflows to split lint/test from build/deploy stages:

```yaml
name: CI/CD Pipeline

on:
  push:
    branches: [main]
  pull_request:
    branches: [main]

jobs:
  validate:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - name: Setup Node
        uses: actions/setup-node@v4
        with:
          node-version: 24
          cache: 'npm'
      - name: Install dependencies
        run: npm ci
      - name: Lint & Typescheck
        run: npm run lint && npm run typecheck
      - name: Run Unit Tests
        run: npm run test

  deploy-staging:
    needs: validate
    if: github.ref == 'refs/heads/main'
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - name: Deploy to Vercel (Staging)
        uses: amondnet/vercel-action@v20
        with:
          vercel-token: ${{ secrets.VERCEL_TOKEN }}
          vercel-org-id: ${{ secrets.VERCEL_ORG_ID }}
          vercel-project-id: ${{ secrets.VERCEL_PROJECT_ID }}
```

---

## 🧱 Infrastructure as Code (IaC) - Terraform Patterns

- **State Lock**: Use S3 backend with DynamoDB locking for AWS projects.
- **Variables**: Never hardcode client credentials in variables. Use `tfvars` files injected in pipeline secrets.
- **Module Versioning**: Pin modules to exact releases to ensure environment reproducibility.

---

## ⚠️ DevOps Anti-Patterns to Avoid
* **Running Containers as root**: Allowing Docker containers to run default root users (`UID 0`), facilitating container escapes and filesystem takeover.
* **Secrets in Image Metadata**: Injecting environment keys or keys into Dockerfile `ENV` statements. These keys become readable to anyone with access to pull the image.
* **Mono-environment Configs**: Storing staging and production configs in the same file instead of isolating variables using environment prefixes.
* **Lack of Build Caching**: Re-downloading all dependencies (e.g. `node_modules` or Docker layers) on every run, resulting in extremely slow pipeline runs.
