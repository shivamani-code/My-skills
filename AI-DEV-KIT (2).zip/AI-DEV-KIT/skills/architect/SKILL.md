# Architect Skill: SaaS System Architecture & API Design

## 🎯 Selective Reading Rule
Use this skill when you are designing database schemas, defining API contracts, establishing project structure, modeling bounded contexts, or planning architectural transitions.

## 🧠 Core Philosophy
A startup SaaS architecture must balance rapid development with robust isolation, scalability, and loose coupling. Enforce clean boundaries between the UI layer, application logic, and the database. Rely on Domain-Driven Design (DDD) principles to organize bounded contexts, model rich domains in PostgreSQL, and build highly secure API layers using Supabase or Node.js.

---

## 🏗️ Next.js App Router Architecture Pattern

For a production Next.js SaaS, structure the application using a layered approach to prevent logic leaks into page components:

```text
src/
├── app/                  # Routing & View Layer (Next.js Pages, Layouts, Server Actions)
├── components/           # UI Component Layer (Stateless & Client UI)
├── lib/                  # Infrastructure & Core Layers
│   ├── modules/          # Bounded Contexts (DDD / Core Business Logic)
│   │   ├── users/        # e.g., Users Module
│   │   │   ├── services/ # Business Logic & Domain Services
│   │   │   ├── actions/  # Encapsulated Mutation Logic
│   │   │   └── types.ts  # Domain Interfaces
│   │   └── billing/      # e.g., Billing Module
│   ├── db/               # Database Connection & Config (Prisma/Drizzle)
│   └── supabase/         # Supabase Client & Middleware Configurations
```

### Server Actions vs Route Handlers
* **Server Actions**: Use for form submissions, mutations, and user-triggered state changes from React components. Always validate inputs via a library like `zod`.
* **Route Handlers (`route.ts`)**: Use for webhooks (e.g. Stripe, SendGrid), public REST APIs, file uploads/downloads, and integrations requiring standard HTTP method responses.

---

## 🌐 API Design Standards

### 1. RESTful Path Guidelines
- Use nouns for resources, not verbs: `/api/workspaces` (Correct) vs `/api/getWorkspaces` (Incorrect).
- Use plural names: `/api/users` (Correct) vs `/api/user` (Incorrect).
- Represent hierarchy via sub-resources: `/api/workspaces/[id]/members`.

### 2. Payload and Response Contract
- Wrap responses in a consistent envelope:
  ```json
  {
    "success": true,
    "data": { ... },
    "meta": { "page": 1, "limit": 10, "total": 100 }
  }
  ```
- Errors must contain structured error details:
  ```json
  {
    "success": false,
    "error": {
      "code": "VALIDATION_FAILED",
      "message": "Invalid email address",
      "details": [{ "field": "email", "issue": "Invalid format" }]
    }
  }
  ```

### 3. Pagination and Filtering
- Always support cursor-based pagination for high-volume endpoints, fallback to limit/offset pagination for tables.
- Return response headers or metadata indicating paging status.

---

## ⚡ Domain-Driven Design (DDD) Guidelines

1. **Entities & Aggregates**: An aggregate is a cluster of associated objects treated as a single unit (e.g. `Invoice` and `InvoiceItem`). Ensure all operations on `InvoiceItem` pass through the `Invoice` aggregate root to enforce domain invariants.
2. **Value Objects**: Objects without conceptual identity, defined by their attributes (e.g. `Money` with amount and currency). Make value objects immutable.
3. **Bounded Contexts**: Keep contexts isolated. Do not allow the `Billing` domain to directly mutate the `User` domain. Use Domain Events or transactional services for cross-boundary side-effects.

---

## ⚠️ Architectural Anti-Patterns to Avoid
* **Fat UI Pages**: Putting database queries, business validation, and layout routing all inside Next.js page components. Extract queries/mutations to Server Actions or dedicated Services.
* **Direct Database Mutation in Client**: Exposing DATABASE_URL directly to frontends or writing client-side SQL without Row-Level Security (RLS) policies.
* **Lack of Rate Limiting**: Exposing public endpoints without IP or token-based rate limiting (using Redis or Supabase edge filters).
* **Distributed Monolith**: In microservices, having services tightly coupled via synchronous HTTP calls. Use asynchronous messaging/webhooks for service-to-service communication.
