# Database Engineer Skill: PostgreSQL, Supabase RLS, Prisma & Drizzle ORM

## 🎯 Selective Reading Rule
Use this skill when you are modeling schemas, writing database migrations, declaring ORM schemas (Prisma/Drizzle), tuning slow SQL queries, or setting up Row-Level Security (RLS) policies.

## 🧠 Core Philosophy
The database is the foundation of SaaS reliability and performance. A database engineer designs normalized, indexed, and secure schemas. In multi-tenant SaaS, tenant isolation must be absolute and mathematically enforced (ideally via Row-Level Security (RLS) at the database engine level or strict service filters). All changes must be deployed via traceable versioned migrations.

---

## 💾 PostgreSQL Table Design & Data Type Standards

### 1. Guideline for Data Types
* **Identifiers**: Use `uuid` (UUIDv4) or `bigint` (auto-incrementing) for primary keys. Never use regular `integer` for tables that will grow beyond 2.1 billion records.
* **Text**: Use `text` instead of `varchar(n)` unless there is a specific validation limit (e.g. state code `varchar(2)`).
* **Timestamps**: Always use `timestamptz` (timestamp with time zone) for dates (e.g., `created_at`, `updated_at`). Never store dates as timezone-naive strings.
* **JSON**: Use `jsonb` instead of `json` for document storage because it supports indexing and binary search.

### 2. Mandatory Columns on Every Table
Every relational user table must include:
```sql
id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
workspace_id uuid NOT NULL REFERENCES workspaces(id) ON DELETE CASCADE,
created_at timestamptz NOT NULL DEFAULT now(),
updated_at timestamptz NOT NULL DEFAULT now()
```

---

## 🛡️ Row-Level Security (RLS) Standards

For Supabase or direct Postgres architectures, always enable RLS on every user-facing table:
```sql
ALTER TABLE documents ENABLE ROW LEVEL SECURITY;
```

### Policy Examples
Create policies using the app authentication context:
```sql
-- Allow users to select only documents belonging to their workspace
CREATE POLICY select_tenant_documents ON documents
  FOR SELECT
  USING (workspace_id IN (
    SELECT id FROM workspaces WHERE user_id = auth.uid()
  ));
```

---

## 🚀 ORM Best Practices: Prisma vs Drizzle

### Prisma Patterns
* **Keep Schemas Clean**: Use `@@map` and `@map` to translate camelCase TypeScript properties to snake_case Postgres columns.
* **Optimization**: Avoid deep relations in queries using nested `include` which can lead to cartesian product explosions. Use selective projections with `select`.

### Drizzle Patterns
* **Type Safety**: Leverage `inferSelectModel` and `inferInsertModel` to generate types dynamically from schema definitions.
* **Relational API**: Use the relational query builder (`db.query.users.findMany`) for simpler setups, or drop down to raw-SQL queries for performance-critical joins.

---

## ⚡ Indexing & Performance Tuning

1. **Foreign Keys**: Always index foreign key columns (`workspace_id`, `user_id`). Postgres does not automatically index foreign keys, causing slow join searches.
2. **Partial Indexes**: Use partial indexes to keep indexes light when searching for filtered rows:
   ```sql
   CREATE INDEX idx_active_subscriptions ON subscriptions(user_id) WHERE status = 'active';
   ```
3. **Query Audits**: Run `EXPLAIN (ANALYZE, BUFFERS)` on slow queries. Check for `Seq Scan` (Sequential Scans) on large tables, which indicates a missing index. Aim for `Index Scan` or `Index Only Scan`.

---

## ⚠️ Database Anti-Patterns to Avoid
* **Null Comparisons**: Writing query lookups using `= NULL` instead of `IS NULL`.
* **Database Logic In App (N+1 Queries)**: Querying a list of records in a loop instead of performing a batch query with `IN` or an SQL `JOIN`.
* **Destructive Migrations**: Deploying database structural adjustments (e.g. dropping columns or changing column types) that break running API code. Use a expand-and-contract model (deploy column addition, migrate data, deploy code switch, drop old column).
* **Missing Constraints**: Relying on server code to maintain data integrity instead of using database constraints (`UNIQUE`, `CHECK`, `NOT NULL`).
