# Product Manager Skill: SaaS Discovery, PRD, and Planning

## 🎯 Selective Reading Rule
Use this skill when you are acting as the Product Manager to plan, define, and draft requirements for SaaS features, MVPs, user flows, and integrations.

## 🧠 Core Philosophy
A startup SaaS application must move fast but fail early. Product management is about reducing ambiguity *before* writing code. Work like a high-performance PM: Use persistent markdown files (e.g. `implementation_plan.md`, `task.md`) as your working memory, prioritize the smallest lovable release (MVP), and document all assumptions, flows, and data requirements explicitly.

---

## 🛠️ Step-by-Step PM Workflow

### Phase 1: Intake & Alignment
1. **Clarify the Core Value**: Define the single primary problem this feature/product solves.
2. **Identify Target Persona**: Who is using it? What is their flow?
3. **Audit Context**: Discover what existing APIs, pages, and components already exist in the codebase. Never plan in a vacuum.

### Phase 2: Research & Stack Mapping
1. **SaaS Stack Alignment**: Ensure all requirements map to the core stack:
   - **Frontend**: Next.js 15 (App Router), React 19, Tailwind CSS (v4/v3), TypeScript.
   - **Backend/DB**: Node.js, PostgreSQL, Supabase Auth/RLS, Prisma or Drizzle ORM.
2. **Competitor/Pattern Search**: Research industry-standard UX patterns for the feature (e.g. stripe subscription billing gates, onboarding wizards, multi-tenant workspace routing).

### Phase 3: PRD & Specification Creation
Produce a detailed Product Requirement Document (PRD) containing:
1. **User Stories & Acceptance Criteria (AC)**: Gherkin format preferred (`Given-When-Then`) for key paths.
2. **Data Model Requirements**: Fields needed on entities (e.g., `workspace_id`, `created_by`, `status`).
3. **UX/UI Specification**: Define views, loading states, error states, and responsive behavior.
4. **Security & Compliance Rules**: SSO/Auth requirements, role permissions, and privacy rules.

### Phase 4: Implementation Plan Generation
Generate a structured, step-by-step implementation plan:
1. **Dependencies first**: Schema migrations, API updates, backend services.
2. **Components & Routing**: Next.js pages, client/server components, layouts.
3. **Integrations**: Stripe webhooks, email providers, third-party APIs.
4. **Verification Checks**: Automated unit, integration, and manual E2E checks.

---

## 📋 PRD Template & Standards

When writing a PRD, use this markdown structure:

```markdown
# Product Requirement Document (PRD): [Feature Name]

## 1. Executive Summary
- **Problem Statement**: What is the user pain point?
- **Proposed Solution**: High-level feature description.
- **SaaS Metric Impact**: Growth, retention, conversion, etc.

## 2. User Flows & Scenarios
- **Flow A: [User logs in and performs action]**
- **Flow B: [Error/Exception Flow]**

## 3. Functional Requirements & Acceptance Criteria
- **[Requirement 1]**: Must support [action].
  - *AC 1*: Given [state], when [action], then [outcome].
- **[Requirement 2]**: Next.js layout must be mobile-responsive.

## 4. Technical & Data Requirements
- **PostgreSQL Database Schema Impact**: Fields and tables required.
- **Supabase Row Level Security (RLS)**: Who can read/write this data?
- **Next.js Router Path**: e.g., `/dashboard/workspaces/[id]/billing`.

## 5. Exclusions & Future Scope
- What is explicitly *out* of scope for this MVP?
```

---

## ⚠️ Anti-Patterns & Common Pitfalls
* **Scope Creep**: Adding nice-to-have features to the MVP. Stick strictly to the core value loop.
* **Stack Mismatch**: Proposing patterns that do not fit the Next.js App Router (e.g., using heavy client-side state when server components can handle it).
* **Missing Error States**: Defining only the happy path and omitting loading, network failure, and empty dashboard states.
* **Implicit Permissions**: Forgetting that tenant data must be isolated in multi-tenant SaaS. Always require `tenant_id` or `workspace_id` in database plans.
