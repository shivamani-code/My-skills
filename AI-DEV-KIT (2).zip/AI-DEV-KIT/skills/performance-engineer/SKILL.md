# Performance Engineer Skill: Core Web Vitals, React Rendering & DB Tuning

## 🎯 Selective Reading Rule
Use this skill when you are troubleshooting slow page loads, profiling React components, reducing JS bundle size, writing caching layers, or optimizing database indexes.

## 🧠 Core Philosophy
Performance is a core product feature. A performance engineer systematically measures, benchmarks, and optimizes application bottlenecks across the client, API, and database. Do not optimize prematurely; rely on real profiling data (Lighthouse, Chrome DevTools, database execution plans) to guide enhancements.

---

## ⚡ Core Web Vitals (CWV) & Next.js Tuning

Aim for green scores on the three primary metrics:

1. **LCP (Largest Contentful Paint) < 2.5s**:
   - **Fix**: Optimize images using Next.js `<Image />` component. Prioritize critical above-the-fold images using the `priority` attribute.
   - **Fix**: Avoid client-side waterfalls by pre-fetching data in Next.js Server Components.

2. **CLS (Cumulative Layout Shift) < 0.1**:
   - **Fix**: Reserve aspect ratio spaces for images, ads, and dynamically loaded elements using Tailwind skeleton utilities.
   - **Fix**: Never insert content dynamically above existing elements without a stable user trigger.

3. **INP (Interaction to Next Paint) < 200ms**:
   - **Fix**: Yield the main thread for heavy CPU computations using `requestIdleCallback` or breaking tasks into microtasks.
   - **Fix**: Defer non-critical scripts (Google Analytics, tag managers) using `next/script` with `strategy="lazyOnload"`.

---

## ⚛️ React Component Performance Tuning

Ensure components render only when necessary:

1. **Isolate State Changes**: Extract ticking timers or localized modal inputs to separate child components so state changes do not trigger re-renders across the entire parent page.
2. **Memoize Expensive Computations**: Use `useMemo` for complex data mapping or calculations:
   ```typescript
   const processedItems = useMemo(() => {
     return heavyFilterAndMap(items);
   }, [items]);
   ```
3. **Stabilize Props**: Use `useCallback` to memoize event handler functions passed to children that are wrapped in `React.memo`.

---

## 🗄️ Database & API Caching Patterns

### 1. Redis Caching
Implement Redis caches for high-traffic, low-write queries (e.g. settings, navigation structures):
```typescript
async function getCachedWorkspace(id: string) {
  const cacheKey = `workspace:${id}`;
  const cached = await redis.get(cacheKey);
  if (cached) return JSON.parse(cached);

  const workspace = await db.select().from(workspaces).where(eq(workspaces.id, id));
  await redis.setex(cacheKey, 3600, JSON.stringify(workspace)); // 1 hour TTL
  return workspace;
}
```

### 2. HTTP Caching & Edge Middleware
- Use `Cache-Control` headers (e.g. `s-maxage=60, stale-while-revalidate=600`) to let CDNs cache public endpoint data.

---

## ⚠️ Performance Anti-Patterns to Avoid
* **Importing Huge Libraries Entirely**: Importing a complete utility library (e.g., `import { lodash } from 'lodash'`) instead of importing specific tree-shaken methods (`import map from 'lodash/map'`).
* **Client-Side Heavy Calculations**: Computing analytical reports on the client side using arrays of thousands of records instead of performing aggregation on PostgreSQL (`COUNT`, `SUM`, `AVG`).
* **Unbounded DB Queries**: Running `SELECT * FROM activity_logs` without paging boundaries (`LIMIT`, `OFFSET`), leading to out-of-memory crashes as data grows.
* **Overuse of useMemo/useCallback**: Wrapping trivial computations in hooks, which adds garbage collection and initialization overhead with no render benefit.
