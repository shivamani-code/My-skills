# Code Reviewer Skill: PR Checklists, Code Quality & Clean Code Standards

## 🎯 Selective Reading Rule
Use this skill when you are reviewing pull requests, inspecting code changes, conducting refactoring passes, or validating code quality gates before release.

## 🧠 Core Philosophy
Code reviews are a mechanism for raising engineering quality and distributing knowledge, not a gatekeeping barrier. A code reviewer prioritizes clarity, simplicity, security, and performance. Guard the codebase against technical debt by enforcing Clean Code principles (single-responsibility functions, explicit error handling, and robust tests).

---

## 🔍 The Step-by-Step Code Review Checklist

Review code changes through the following five progressive lenses:

### 1. Functional Review
- Does the code solve the target problem?
- Are edge cases (empty states, loading timeouts, invalid types) covered?
- Does it conform to the PRD acceptance criteria?

### 2. Architectural & Clean Code Review
- **Single Responsibility (SRP)**: Do functions or classes do one thing? If a function is longer than 30 lines, split it.
- **Meaningful Naming**: Are variables and functions named by intent (`getWorkspaceBySlug` rather than `fetchWS`)?
- **Magic Values**: Are hardcoded strings/numbers extracted to constants or configuration files?
- **DRY (Don't Repeat Yourself)**: Are there duplicate blocks of copy-pasted logic?

### 3. Security Audit
- Are parameters sanitized? Is there any risk of SQL injection or XSS?
- **Permissions check**: Are backend routes verifying tenant ownership of resources?
- Are sensitive API credentials or secret values hardcoded?

### 4. Performance Audit
- Are database queries optimized? (Are there any N+1 loops?)
- **UI Render Profiling**: Are React components triggering unnecessary heavy re-renders?
- Are imports tree-shaken, or does the code drag in unused heavy dependencies?

### 5. Test Coverage
- Are there unit tests covering the new logic?
- Are edge cases covered in tests, or only the happy paths?
- Do mock assertions represent real-world API responses?

---

## 🛠️ Code Smell & Heuristic Reference

Keep watch for these typical code smells:

* **Long Methods**: Functions containing many nested statements, conditional branches, or mixed concerns.
* **Large Class/Component**: UI components containing over 300 lines of code. Extract sub-components.
* **Temporal Coupling**: Functions that must be executed in a specific sequence but have no programmatic enforcement (fix by wrapping them in a pipeline or transaction).
* **Duplicated Code**: Refactor repeating code into helper modules or reusable UI components.

---

## ⚠️ Code Review Anti-Patterns to Avoid
* **Nitpicking Formatting**: Commenting on code formatting style issues (spacing, semicolons) that should be automatically handled by `prettier` or `eslint`. Let the pre-commit linter handle style.
* **Aggressive Feedback**: Writing critical comments without providing actionable recommendations or context. Always state the *why* behind a requested change.
* **Reviewing Without Context**: Reviewing changes without knowing the related PRD or database schema updates.
